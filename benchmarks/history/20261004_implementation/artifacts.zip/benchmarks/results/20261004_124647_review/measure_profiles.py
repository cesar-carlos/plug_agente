import contextlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

REPO = Path(r'D:/Developer/plug_database/plug_agente')
BASE = Path(r'C:/Users/cesar/AppData/Local/Temp/plug-benchmark-base-e38d09fb922f43c58d09a06064ac82fe/source')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from tool.py.benchmark_common import bootstrap_env, parse_gateway_encoding_metrics, parse_plug_agente_stack_metrics, parse_odbc_streaming_benchmark_metrics, resolve_dart_odbc_fast_root
from tool.py.odbc_benchmark_runner import run_odbc_async_benchmark, run_odbc_streaming_benchmark
from tool.py.odbc_benchmark_gate import parse_async_benchmark_scenarios
from tool.py.script_utils import resolve_command

bootstrap_env(REPO / '.env')
package = resolve_dart_odbc_fast_root()
original_env = os.environ.copy()
report = {'driver_profiles': [], 'encoding_repetitions': [], 'stack_repetitions': []}

def save():
    (ROOT / 'supplemental-measurements.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

drivers = [
    ('sql_anywhere', original_env.get('ODBC_TEST_DSN') or original_env.get('ODBC_DSN'),
     'SELECT TOP 8000 a.table_id AS id, a.table_name AS name, a.table_type FROM SYS.SYSTABLE a CROSS JOIN SYS.SYSTABLE b'),
    ('sql_server', original_env.get('ODBC_TEST_DSN_SQL_SERVER') or original_env.get('ODBC_DSN_SQL_SERVER'),
     "WITH n AS (SELECT 1 AS id UNION ALL SELECT id + 1 FROM n WHERE id < 8000) SELECT id, CAST('benchmark-row' AS varchar(20)) AS name FROM n OPTION (MAXRECURSION 0)"),
]

for driver, dsn, query in drivers:
    if not dsn:
        continue
    print('Measuring representative ODBC profile: ' + driver, flush=True)
    os.environ.update({'ODBC_BENCH_DRIVER_DSN': dsn, 'ODBC_TEST_DSN': dsn,
                       'ODBC_BENCH_QUERY': query, 'ODBC_STREAM_BENCH_QUERY': query})
    for repeat in range(3):
        entry = {'driver': driver, 'repeat': repeat, 'query': query}
        for kind, runner in [('async', run_odbc_async_benchmark), ('streaming', run_odbc_streaming_benchmark)]:
            log = ROOT / f'representative_{driver}_{kind}_{repeat}.log'
            with (ROOT / 'supplemental-runner.log').open('a', encoding='utf-8') as capture:
                with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
                    code, metrics, output = runner(package_root=package, log_path=log)
            parsed = parse_odbc_streaming_benchmark_metrics(output) if kind == 'streaming' else {
                s.label: {'duration_ms': s.duration_ms, 'encoding': s.encoding, 'fallbacks': s.fallbacks}
                for s in parse_async_benchmark_scenarios(output)
            }
            entry[kind] = {'exit_code': code, 'metrics': parsed, 'log': log.name}
        report['driver_profiles'].append(entry)
        save()
        print(driver + ' profile repeat ' + str(repeat) + ' completed', flush=True)

os.environ.clear()
os.environ.update(original_env)
for driver, dsn, query in drivers:
    if not dsn:
        continue
    os.environ['ODBC_TEST_DSN'] = dsn
    os.environ.pop('ODBC_BENCH_QUERY', None)
    for repeat in range(5):
        log = ROOT / f'encoding_{driver}_{repeat}.log'
        with log.open('w', encoding='utf-8') as capture:
            result = subprocess.run(resolve_command(['flutter', 'test', 'test/tool/odbc_gateway_encoding_benchmark_test.dart', '--concurrency=1']), cwd=REPO, stdout=capture, stderr=subprocess.STDOUT, timeout=300)
        metrics = parse_gateway_encoding_metrics(log.read_text(encoding='utf-8'))
        report['encoding_repetitions'].append({'driver': driver, 'repeat': repeat, 'exit_code': result.returncode, 'metrics': metrics, 'log': log.name})
        save()
        print(driver + ' encoding repeat ' + str(repeat) + ' completed', flush=True)

os.environ.clear()
os.environ.update(original_env)
for repeat in range(5):
    order = [('base', BASE), ('candidate', REPO)] if repeat % 2 == 0 else [('candidate', REPO), ('base', BASE)]
    for name, cwd in order:
        log = ROOT / f'stack_{name}_{repeat}.log'
        with log.open('w', encoding='utf-8') as capture:
            result = subprocess.run(resolve_command(['flutter', 'test', 'test/tool/plug_agente_stack_benchmark_test.dart', 'test/tool/odbc_hot_paths_benchmark_test.dart', '--concurrency=1']), cwd=cwd, stdout=capture, stderr=subprocess.STDOUT, timeout=300)
        output = log.read_text(encoding='utf-8')
        metrics = parse_plug_agente_stack_metrics(output)
        for line in output.splitlines():
            normalized = line.removeprefix('Shell: ').strip()
            try:
                payload = json.loads(normalized)
            except json.JSONDecodeError:
                continue
            if payload.get('benchmark') == 'odbc_hot_paths':
                for row in payload['scenarios']:
                    for key in ['p50_us', 'p95_us', 'p99_us']:
                        metrics['hot_paths.' + row['scenario'] + '.' + key] = row[key]
        report['stack_repetitions'].append({'revision': name, 'repeat': repeat, 'exit_code': result.returncode, 'metrics': metrics, 'log': log.name})
        save()
        print(name + ' stack repeat ' + str(repeat) + ' completed', flush=True)

save()
print('Supplemental measurements completed', flush=True)
