# Relatório de benchmark — plug_agente

- Run ID: `20261004_124648`
- Capturado em: 2026-10-04T12:47:24-04:00
- Commit: `bdfd3ad00edad28e25f8cb6361eda3b8b1c9c785` (main)
- Working tree dirty: True
- Plataforma: Windows-11-10.0.26300-SP0

## Suites

### transport_pipeline
- Status: **pass**
- Wall time: 14483.25 ms
- Log: `transport_pipeline.log`
- Métricas:
  - `large_incompressible_blob.async.auto.signed_False.receive_p50_us`: 7200.0
  - `large_incompressible_blob.async.auto.signed_False.receive_p95_us`: 10600.0
  - `large_incompressible_blob.async.auto.signed_False.receive_p99_us`: 10600.0
  - `large_incompressible_blob.async.auto.signed_False.send_p50_us`: 24300.0
  - `large_incompressible_blob.async.auto.signed_False.send_p95_us`: 24900.0
  - `large_incompressible_blob.async.auto.signed_False.send_p99_us`: 24900.0
  - `large_incompressible_blob.async.auto.signed_True.receive_p50_us`: 6100.0
  - `large_incompressible_blob.async.auto.signed_True.receive_p95_us`: 11600.0
  - `large_incompressible_blob.async.auto.signed_True.receive_p99_us`: 11600.0
  - `large_incompressible_blob.async.auto.signed_True.send_p50_us`: 22000.0
  - `large_incompressible_blob.async.auto.signed_True.send_p95_us`: 24000.0
  - `large_incompressible_blob.async.auto.signed_True.send_p99_us`: 24000.0
  - `large_incompressible_blob.async.gzip.signed_False.receive_p50_us`: 6000.0
  - `large_incompressible_blob.async.gzip.signed_False.receive_p95_us`: 7100.0
  - `large_incompressible_blob.async.gzip.signed_False.receive_p99_us`: 7100.0
  - `large_incompressible_blob.async.gzip.signed_False.send_p50_us`: 24100.0
  - `large_incompressible_blob.async.gzip.signed_False.send_p95_us`: 24800.0
  - `large_incompressible_blob.async.gzip.signed_False.send_p99_us`: 24800.0
  - `large_incompressible_blob.async.gzip.signed_True.receive_p50_us`: 5600.0
  - `large_incompressible_blob.async.gzip.signed_True.receive_p95_us`: 5700.0
  - `large_incompressible_blob.async.gzip.signed_True.receive_p99_us`: 5700.0
  - `large_incompressible_blob.async.gzip.signed_True.send_p50_us`: 19600.0
  - `large_incompressible_blob.async.gzip.signed_True.send_p95_us`: 20600.0
  - `large_incompressible_blob.async.gzip.signed_True.send_p99_us`: 20600.0
  - `large_incompressible_blob.async.none.signed_False.receive_p50_us`: 2900.0
  - `large_incompressible_blob.async.none.signed_False.receive_p95_us`: 2900.0
  - `large_incompressible_blob.async.none.signed_False.receive_p99_us`: 2900.0
  - `large_incompressible_blob.async.none.signed_False.send_p50_us`: 7500.0
  - `large_incompressible_blob.async.none.signed_False.send_p95_us`: 8100.0
  - `large_incompressible_blob.async.none.signed_False.send_p99_us`: 8100.0
  - `large_incompressible_blob.async.none.signed_True.receive_p50_us`: 1800.0
  - `large_incompressible_blob.async.none.signed_True.receive_p95_us`: 3800.0
  - `large_incompressible_blob.async.none.signed_True.receive_p99_us`: 3800.0
  - `large_incompressible_blob.async.none.signed_True.send_p50_us`: 5900.0
  - `large_incompressible_blob.async.none.signed_True.send_p95_us`: 8700.0
  - `large_incompressible_blob.async.none.signed_True.send_p99_us`: 8700.0
  - `large_sql_low_compressibility.async.auto.signed_False.receive_p50_us`: 4100.0
  - `large_sql_low_compressibility.async.auto.signed_False.receive_p95_us`: 4800.0
  - `large_sql_low_compressibility.async.auto.signed_False.receive_p99_us`: 4800.0
  - `large_sql_low_compressibility.async.auto.signed_False.send_p50_us`: 10700.0
  - `large_sql_low_compressibility.async.auto.signed_False.send_p95_us`: 11500.0
  - `large_sql_low_compressibility.async.auto.signed_False.send_p99_us`: 11500.0
  - `large_sql_low_compressibility.async.auto.signed_True.receive_p50_us`: 3800.0
  - `large_sql_low_compressibility.async.auto.signed_True.receive_p95_us`: 4000.0
  - `large_sql_low_compressibility.async.auto.signed_True.receive_p99_us`: 4000.0
  - `large_sql_low_compressibility.async.auto.signed_True.send_p50_us`: 9900.0
  - `large_sql_low_compressibility.async.auto.signed_True.send_p95_us`: 10500.0
  - `large_sql_low_compressibility.async.auto.signed_True.send_p99_us`: 10500.0
  - `large_sql_low_compressibility.async.gzip.signed_False.receive_p50_us`: 3900.0
  - `large_sql_low_compressibility.async.gzip.signed_False.receive_p95_us`: 4100.0
  - `large_sql_low_compressibility.async.gzip.signed_False.receive_p99_us`: 4100.0
  - `large_sql_low_compressibility.async.gzip.signed_False.send_p50_us`: 11000.0
  - `large_sql_low_compressibility.async.gzip.signed_False.send_p95_us`: 11200.0
  - `large_sql_low_compressibility.async.gzip.signed_False.send_p99_us`: 11200.0
  - `large_sql_low_compressibility.async.gzip.signed_True.receive_p50_us`: 4200.0
  - `large_sql_low_compressibility.async.gzip.signed_True.receive_p95_us`: 15900.0
  - `large_sql_low_compressibility.async.gzip.signed_True.receive_p99_us`: 15900.0
  - `large_sql_low_compressibility.async.gzip.signed_True.send_p50_us`: 12300.0
  - `large_sql_low_compressibility.async.gzip.signed_True.send_p95_us`: 14300.0
  - `large_sql_low_compressibility.async.gzip.signed_True.send_p99_us`: 14300.0
  - `large_sql_low_compressibility.async.none.signed_False.receive_p50_us`: 4500.0
  - `large_sql_low_compressibility.async.none.signed_False.receive_p95_us`: 7000.0
  - `large_sql_low_compressibility.async.none.signed_False.receive_p99_us`: 7000.0
  - `large_sql_low_compressibility.async.none.signed_False.send_p50_us`: 10500.0
  - `large_sql_low_compressibility.async.none.signed_False.send_p95_us`: 10800.0
  - `large_sql_low_compressibility.async.none.signed_False.send_p99_us`: 10800.0
  - `large_sql_low_compressibility.async.none.signed_True.receive_p50_us`: 6700.0
  - `large_sql_low_compressibility.async.none.signed_True.receive_p95_us`: 7700.0
  - `large_sql_low_compressibility.async.none.signed_True.receive_p99_us`: 7700.0
  - `large_sql_low_compressibility.async.none.signed_True.send_p50_us`: 8400.0
  - `large_sql_low_compressibility.async.none.signed_True.send_p95_us`: 9000.0
  - `large_sql_low_compressibility.async.none.signed_True.send_p99_us`: 9000.0
  - `small_sql_repetitive.async.auto.signed_False.receive_p50_us`: 66.0
  - `small_sql_repetitive.async.auto.signed_False.receive_p95_us`: 114.0
  - `small_sql_repetitive.async.auto.signed_False.receive_p99_us`: 114.0
  - `small_sql_repetitive.async.auto.signed_False.send_p50_us`: 219.0
  - `small_sql_repetitive.async.auto.signed_False.send_p95_us`: 300.0
  - `small_sql_repetitive.async.auto.signed_False.send_p99_us`: 300.0
  - `small_sql_repetitive.async.auto.signed_True.receive_p50_us`: 165.0
  - `small_sql_repetitive.async.auto.signed_True.receive_p95_us`: 171.0
  - `small_sql_repetitive.async.auto.signed_True.receive_p99_us`: 171.0
  - `small_sql_repetitive.async.auto.signed_True.send_p50_us`: 162.0
  - `small_sql_repetitive.async.auto.signed_True.send_p95_us`: 194.0
  - `small_sql_repetitive.async.auto.signed_True.send_p99_us`: 194.0
  - `small_sql_repetitive.async.gzip.signed_False.receive_p50_us`: 71.0
  - `small_sql_repetitive.async.gzip.signed_False.receive_p95_us`: 72.0
  - `small_sql_repetitive.async.gzip.signed_False.receive_p99_us`: 72.0
  - `small_sql_repetitive.async.gzip.signed_False.send_p50_us`: 192.0
  - `small_sql_repetitive.async.gzip.signed_False.send_p95_us`: 302.0
  - `small_sql_repetitive.async.gzip.signed_False.send_p99_us`: 302.0
  - `small_sql_repetitive.async.gzip.signed_True.receive_p50_us`: 76.0
  - `small_sql_repetitive.async.gzip.signed_True.receive_p95_us`: 83.0
  - `small_sql_repetitive.async.gzip.signed_True.receive_p99_us`: 83.0
  - `small_sql_repetitive.async.gzip.signed_True.send_p50_us`: 124.0
  - `small_sql_repetitive.async.gzip.signed_True.send_p95_us`: 129.0
  - `small_sql_repetitive.async.gzip.signed_True.send_p99_us`: 129.0
  - `small_sql_repetitive.async.none.signed_False.receive_p50_us`: 87.0
  - `small_sql_repetitive.async.none.signed_False.receive_p95_us`: 92.0
  - `small_sql_repetitive.async.none.signed_False.receive_p99_us`: 92.0
  - `small_sql_repetitive.async.none.signed_False.send_p50_us`: 103.0
  - `small_sql_repetitive.async.none.signed_False.send_p95_us`: 415.0
  - `small_sql_repetitive.async.none.signed_False.send_p99_us`: 415.0
  - `small_sql_repetitive.async.none.signed_True.receive_p50_us`: 82.0
  - `small_sql_repetitive.async.none.signed_True.receive_p95_us`: 112.0
  - `small_sql_repetitive.async.none.signed_True.receive_p99_us`: 112.0
  - `small_sql_repetitive.async.none.signed_True.send_p50_us`: 139.0
  - `small_sql_repetitive.async.none.signed_True.send_p95_us`: 196.0
  - `small_sql_repetitive.async.none.signed_True.send_p99_us`: 196.0

### plug_agente_stack
- Status: **pass**
- Wall time: 4905.82 ms
- Log: `plug_agente_stack.log`
- Métricas:
  - `backpressure_stream_emitter.concurrent_admission.median_us`: 1274.0
  - `backpressure_stream_emitter.concurrent_admission.speedup`: 1.2087912087912087
  - `backpressure_stream_emitter.sequential_admission.median_us`: 1540.0
  - `columnar_stream_emitter.row_map.median_us`: 788.0
  - `columnar_stream_emitter.row_map.rows_per_sec`: 1269035.5329949239
  - `columnar_stream_emitter.wire_only.median_us`: 18.0
  - `columnar_stream_emitter.wire_only.rows_per_sec`: 55555555.55555555
  - `columnar_stream_emitter.wire_only.speedup`: 43.77777777777778
  - `config_metadata_cache.cold.median_us`: 44.0
  - `config_metadata_cache.cold.p95_us`: 95.0
  - `config_metadata_cache.warm.median_us`: 4.0
  - `config_metadata_cache.warm.p95_us`: 10.0
  - `config_metadata_cache.warm.speedup`: 11.0
  - `odbc_connection_string_ttl_cache.cold.median_us`: 1.0
  - `odbc_connection_string_ttl_cache.cold.p95_us`: 3.0
  - `odbc_connection_string_ttl_cache.warm.median_us`: 0.0
  - `odbc_connection_string_ttl_cache.warm.p95_us`: 0.0
  - `odbc_connection_string_ttl_cache.warm.speedup`: 1.0
  - `queued_database_gateway.execute_query.median_us`: 76.0
  - `queued_database_gateway.execute_query.p95_us`: 113.0
  - `sql_rpc_db_streaming_executor.cold_config_cache.median_us`: 148.0
  - `sql_rpc_db_streaming_executor.warm_config_cache.median_us`: 122.0
  - `sql_rpc_db_streaming_executor.warm_config_cache.speedup`: 1.21

### odbc_hot_paths
- Status: **pass**
- Wall time: 4627.43 ms
- Log: `odbc_hot_paths.log`

### transport_pipeline_json
- Status: **skipped**
- Motivo: plain `dart run` cannot compile FFI/isolate offload in this workspace; use flutter_test transport_pipeline or pass --no-skip-dart-tool for local experiments

### odbc_async
- Status: **pass**
- Wall time: 3620.63 ms
- Log: `odbc_async.log`
- Métricas:
  - `package_version`: 5.0.0
  - `wall_ms`: 3620.631500001764

### odbc_streaming
- Status: **pass**
- Wall time: 3448.47 ms
- Log: `odbc_streaming.log`
- Métricas:
  - `package_version`: 5.0.0
  - `streamQuery.chunk_size`: 1048576.0
  - `streamQuery.chunks`: 1.0
  - `streamQuery.elapsed_ms`: 534.353
  - `streamQuery.fetch_size`: 0.0
  - `streamQuery.rows`: 0.0
  - `streamQuery.rows_per_second`: 0.0
  - `streamQueryBatched.chunk_size`: 1048576.0
  - `streamQueryBatched.chunks`: 1.0
  - `streamQueryBatched.elapsed_ms`: 5.817
  - `streamQueryBatched.fetch_size`: 1000.0
  - `streamQueryBatched.rows`: 0.0
  - `streamQueryBatched.rows_per_second`: 0.0
  - `wall_ms`: 3448.469799972372

### odbc_gateway_encoding
- Status: **pass**
- Wall time: 4784.39 ms
- Log: `odbc_gateway_encoding.log`
- Métricas:
  - `median_us_balancedServer_rowMajor`: 9182.0
  - `median_us_explicit_columnarCompressed`: 7419.0
  - `median_us_highThroughput_columnar`: 7312.0

## Comparação com baseline

```bash
python tool/benchmarks/compare_benchmark_summary.py \
  --baseline benchmarks/baseline/summary.json \
  --current benchmarks/results/20261004_124648/summary.json
```
