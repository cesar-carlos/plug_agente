# Relatório de benchmark — plug_agente

- Run ID: `20261004_123740`
- Capturado em: 2026-10-04T12:38:14-04:00
- Commit: `bdfd3ad00edad28e25f8cb6361eda3b8b1c9c785` (main)
- Working tree dirty: True
- Plataforma: Windows-11-10.0.26300-SP0

## Suites

### transport_pipeline
- Status: **pass**
- Wall time: 14220.63 ms
- Log: `transport_pipeline.log`
- Métricas:
  - `large_incompressible_blob.async.auto.signed_False.receive_p50_us`: 7500.0
  - `large_incompressible_blob.async.auto.signed_False.receive_p95_us`: 9700.0
  - `large_incompressible_blob.async.auto.signed_False.receive_p99_us`: 9700.0
  - `large_incompressible_blob.async.auto.signed_False.send_p50_us`: 22900.0
  - `large_incompressible_blob.async.auto.signed_False.send_p95_us`: 24300.0
  - `large_incompressible_blob.async.auto.signed_False.send_p99_us`: 24300.0
  - `large_incompressible_blob.async.auto.signed_True.receive_p50_us`: 9800.0
  - `large_incompressible_blob.async.auto.signed_True.receive_p95_us`: 11400.0
  - `large_incompressible_blob.async.auto.signed_True.receive_p99_us`: 11400.0
  - `large_incompressible_blob.async.auto.signed_True.send_p50_us`: 24200.0
  - `large_incompressible_blob.async.auto.signed_True.send_p95_us`: 27300.0
  - `large_incompressible_blob.async.auto.signed_True.send_p99_us`: 27300.0
  - `large_incompressible_blob.async.gzip.signed_False.receive_p50_us`: 7300.0
  - `large_incompressible_blob.async.gzip.signed_False.receive_p95_us`: 7300.0
  - `large_incompressible_blob.async.gzip.signed_False.receive_p99_us`: 7300.0
  - `large_incompressible_blob.async.gzip.signed_False.send_p50_us`: 25800.0
  - `large_incompressible_blob.async.gzip.signed_False.send_p95_us`: 29000.0
  - `large_incompressible_blob.async.gzip.signed_False.send_p99_us`: 29000.0
  - `large_incompressible_blob.async.gzip.signed_True.receive_p50_us`: 6000.0
  - `large_incompressible_blob.async.gzip.signed_True.receive_p95_us`: 11100.0
  - `large_incompressible_blob.async.gzip.signed_True.receive_p99_us`: 11100.0
  - `large_incompressible_blob.async.gzip.signed_True.send_p50_us`: 24400.0
  - `large_incompressible_blob.async.gzip.signed_True.send_p95_us`: 24900.0
  - `large_incompressible_blob.async.gzip.signed_True.send_p99_us`: 24900.0
  - `large_incompressible_blob.async.none.signed_False.receive_p50_us`: 1600.0
  - `large_incompressible_blob.async.none.signed_False.receive_p95_us`: 1600.0
  - `large_incompressible_blob.async.none.signed_False.receive_p99_us`: 1600.0
  - `large_incompressible_blob.async.none.signed_False.send_p50_us`: 5700.0
  - `large_incompressible_blob.async.none.signed_False.send_p95_us`: 6200.0
  - `large_incompressible_blob.async.none.signed_False.send_p99_us`: 6200.0
  - `large_incompressible_blob.async.none.signed_True.receive_p50_us`: 1600.0
  - `large_incompressible_blob.async.none.signed_True.receive_p95_us`: 3000.0
  - `large_incompressible_blob.async.none.signed_True.receive_p99_us`: 3000.0
  - `large_incompressible_blob.async.none.signed_True.send_p50_us`: 6000.0
  - `large_incompressible_blob.async.none.signed_True.send_p95_us`: 8700.0
  - `large_incompressible_blob.async.none.signed_True.send_p99_us`: 8700.0
  - `large_sql_low_compressibility.async.auto.signed_False.receive_p50_us`: 4200.0
  - `large_sql_low_compressibility.async.auto.signed_False.receive_p95_us`: 4800.0
  - `large_sql_low_compressibility.async.auto.signed_False.receive_p99_us`: 4800.0
  - `large_sql_low_compressibility.async.auto.signed_False.send_p50_us`: 10900.0
  - `large_sql_low_compressibility.async.auto.signed_False.send_p95_us`: 11300.0
  - `large_sql_low_compressibility.async.auto.signed_False.send_p99_us`: 11300.0
  - `large_sql_low_compressibility.async.auto.signed_True.receive_p50_us`: 3800.0
  - `large_sql_low_compressibility.async.auto.signed_True.receive_p95_us`: 4400.0
  - `large_sql_low_compressibility.async.auto.signed_True.receive_p99_us`: 4400.0
  - `large_sql_low_compressibility.async.auto.signed_True.send_p50_us`: 10000.0
  - `large_sql_low_compressibility.async.auto.signed_True.send_p95_us`: 10200.0
  - `large_sql_low_compressibility.async.auto.signed_True.send_p99_us`: 10200.0
  - `large_sql_low_compressibility.async.gzip.signed_False.receive_p50_us`: 4300.0
  - `large_sql_low_compressibility.async.gzip.signed_False.receive_p95_us`: 7300.0
  - `large_sql_low_compressibility.async.gzip.signed_False.receive_p99_us`: 7300.0
  - `large_sql_low_compressibility.async.gzip.signed_False.send_p50_us`: 10400.0
  - `large_sql_low_compressibility.async.gzip.signed_False.send_p95_us`: 11200.0
  - `large_sql_low_compressibility.async.gzip.signed_False.send_p99_us`: 11200.0
  - `large_sql_low_compressibility.async.gzip.signed_True.receive_p50_us`: 3700.0
  - `large_sql_low_compressibility.async.gzip.signed_True.receive_p95_us`: 4000.0
  - `large_sql_low_compressibility.async.gzip.signed_True.receive_p99_us`: 4000.0
  - `large_sql_low_compressibility.async.gzip.signed_True.send_p50_us`: 10100.0
  - `large_sql_low_compressibility.async.gzip.signed_True.send_p95_us`: 11000.0
  - `large_sql_low_compressibility.async.gzip.signed_True.send_p99_us`: 11000.0
  - `large_sql_low_compressibility.async.none.signed_False.receive_p50_us`: 3900.0
  - `large_sql_low_compressibility.async.none.signed_False.receive_p95_us`: 7000.0
  - `large_sql_low_compressibility.async.none.signed_False.receive_p99_us`: 7000.0
  - `large_sql_low_compressibility.async.none.signed_False.send_p50_us`: 9800.0
  - `large_sql_low_compressibility.async.none.signed_False.send_p95_us`: 10100.0
  - `large_sql_low_compressibility.async.none.signed_False.send_p99_us`: 10100.0
  - `large_sql_low_compressibility.async.none.signed_True.receive_p50_us`: 6400.0
  - `large_sql_low_compressibility.async.none.signed_True.receive_p95_us`: 8400.0
  - `large_sql_low_compressibility.async.none.signed_True.receive_p99_us`: 8400.0
  - `large_sql_low_compressibility.async.none.signed_True.send_p50_us`: 7600.0
  - `large_sql_low_compressibility.async.none.signed_True.send_p95_us`: 8600.0
  - `large_sql_low_compressibility.async.none.signed_True.send_p99_us`: 8600.0
  - `small_sql_repetitive.async.auto.signed_False.receive_p50_us`: 88.0
  - `small_sql_repetitive.async.auto.signed_False.receive_p95_us`: 98.0
  - `small_sql_repetitive.async.auto.signed_False.receive_p99_us`: 98.0
  - `small_sql_repetitive.async.auto.signed_False.send_p50_us`: 186.0
  - `small_sql_repetitive.async.auto.signed_False.send_p95_us`: 318.0
  - `small_sql_repetitive.async.auto.signed_False.send_p99_us`: 318.0
  - `small_sql_repetitive.async.auto.signed_True.receive_p50_us`: 89.0
  - `small_sql_repetitive.async.auto.signed_True.receive_p95_us`: 92.0
  - `small_sql_repetitive.async.auto.signed_True.receive_p99_us`: 92.0
  - `small_sql_repetitive.async.auto.signed_True.send_p50_us`: 134.0
  - `small_sql_repetitive.async.auto.signed_True.send_p95_us`: 140.0
  - `small_sql_repetitive.async.auto.signed_True.send_p99_us`: 140.0
  - `small_sql_repetitive.async.gzip.signed_False.receive_p50_us`: 64.0
  - `small_sql_repetitive.async.gzip.signed_False.receive_p95_us`: 72.0
  - `small_sql_repetitive.async.gzip.signed_False.receive_p99_us`: 72.0
  - `small_sql_repetitive.async.gzip.signed_False.send_p50_us`: 201.0
  - `small_sql_repetitive.async.gzip.signed_False.send_p95_us`: 303.0
  - `small_sql_repetitive.async.gzip.signed_False.send_p99_us`: 303.0
  - `small_sql_repetitive.async.gzip.signed_True.receive_p50_us`: 69.0
  - `small_sql_repetitive.async.gzip.signed_True.receive_p95_us`: 83.0
  - `small_sql_repetitive.async.gzip.signed_True.receive_p99_us`: 83.0
  - `small_sql_repetitive.async.gzip.signed_True.send_p50_us`: 122.0
  - `small_sql_repetitive.async.gzip.signed_True.send_p95_us`: 150.0
  - `small_sql_repetitive.async.gzip.signed_True.send_p99_us`: 150.0
  - `small_sql_repetitive.async.none.signed_False.receive_p50_us`: 29.0
  - `small_sql_repetitive.async.none.signed_False.receive_p95_us`: 72.0
  - `small_sql_repetitive.async.none.signed_False.receive_p99_us`: 72.0
  - `small_sql_repetitive.async.none.signed_False.send_p50_us`: 66.0
  - `small_sql_repetitive.async.none.signed_False.send_p95_us`: 172.0
  - `small_sql_repetitive.async.none.signed_False.send_p99_us`: 172.0
  - `small_sql_repetitive.async.none.signed_True.receive_p50_us`: 72.0
  - `small_sql_repetitive.async.none.signed_True.receive_p95_us`: 99.0
  - `small_sql_repetitive.async.none.signed_True.receive_p99_us`: 99.0
  - `small_sql_repetitive.async.none.signed_True.send_p50_us`: 102.0
  - `small_sql_repetitive.async.none.signed_True.send_p95_us`: 121.0
  - `small_sql_repetitive.async.none.signed_True.send_p99_us`: 121.0

### plug_agente_stack
- Status: **pass**
- Wall time: 4638.72 ms
- Log: `plug_agente_stack.log`
- Métricas:
  - `backpressure_stream_emitter.concurrent_admission.median_us`: 1336.0
  - `backpressure_stream_emitter.concurrent_admission.speedup`: 1.4558383233532934
  - `backpressure_stream_emitter.sequential_admission.median_us`: 1945.0
  - `columnar_stream_emitter.row_map.median_us`: 815.0
  - `columnar_stream_emitter.row_map.rows_per_sec`: 1226993.865030675
  - `columnar_stream_emitter.wire_only.median_us`: 19.0
  - `columnar_stream_emitter.wire_only.rows_per_sec`: 52631578.94736842
  - `columnar_stream_emitter.wire_only.speedup`: 42.89473684210526
  - `config_metadata_cache.cold.median_us`: 47.0
  - `config_metadata_cache.cold.p95_us`: 112.0
  - `config_metadata_cache.warm.median_us`: 4.0
  - `config_metadata_cache.warm.p95_us`: 8.0
  - `config_metadata_cache.warm.speedup`: 11.75
  - `odbc_connection_string_ttl_cache.cold.median_us`: 1.0
  - `odbc_connection_string_ttl_cache.cold.p95_us`: 2.0
  - `odbc_connection_string_ttl_cache.warm.median_us`: 0.0
  - `odbc_connection_string_ttl_cache.warm.p95_us`: 0.0
  - `odbc_connection_string_ttl_cache.warm.speedup`: 1.0
  - `queued_database_gateway.execute_query.median_us`: 90.0
  - `queued_database_gateway.execute_query.p95_us`: 143.0
  - `sql_rpc_db_streaming_executor.cold_config_cache.median_us`: 185.0
  - `sql_rpc_db_streaming_executor.warm_config_cache.median_us`: 141.0
  - `sql_rpc_db_streaming_executor.warm_config_cache.speedup`: 1.31

### odbc_hot_paths
- Status: **pass**
- Wall time: 4363.02 ms
- Log: `odbc_hot_paths.log`

### transport_pipeline_json
- Status: **skipped**
- Motivo: plain `dart run` cannot compile FFI/isolate offload in this workspace; use flutter_test transport_pipeline or pass --no-skip-dart-tool for local experiments

### odbc_async
- Status: **pass**
- Wall time: 3406.91 ms
- Log: `odbc_async.log`
- Métricas:
  - `package_version`: 5.0.0
  - `wall_ms`: 3406.9106000242755

### odbc_streaming
- Status: **pass**
- Wall time: 2766.37 ms
- Log: `odbc_streaming.log`
- Métricas:
  - `package_version`: 5.0.0
  - `streamQuery.chunk_size`: 1048576.0
  - `streamQuery.chunks`: 1.0
  - `streamQuery.elapsed_ms`: 491.865
  - `streamQuery.fetch_size`: 0.0
  - `streamQuery.rows`: 0.0
  - `streamQuery.rows_per_second`: 0.0
  - `streamQueryBatched.chunk_size`: 1048576.0
  - `streamQueryBatched.chunks`: 1.0
  - `streamQueryBatched.elapsed_ms`: 5.718
  - `streamQueryBatched.fetch_size`: 1000.0
  - `streamQueryBatched.rows`: 0.0
  - `streamQueryBatched.rows_per_second`: 0.0
  - `wall_ms`: 2766.374099999666

### odbc_gateway_encoding
- Status: **pass**
- Wall time: 4380.43 ms
- Log: `odbc_gateway_encoding.log`
- Métricas:
  - `median_us_balancedServer_rowMajor`: 16260.0
  - `median_us_explicit_columnarCompressed`: 16120.0
  - `median_us_highThroughput_columnar`: 13622.0

## Comparação com baseline

```bash
python tool/benchmarks/compare_benchmark_summary.py \
  --baseline benchmarks/baseline/summary.json \
  --current benchmarks/results/20261004_123740/summary.json
```
