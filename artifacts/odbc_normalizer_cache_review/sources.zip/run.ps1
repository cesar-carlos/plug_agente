$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Push-Location $repoRoot
try {
    $benchShell = Get-Process -Id $PID
    $originalAffinity = $benchShell.ProcessorAffinity
    try {
        $benchShell.ProcessorAffinity = 4
        foreach ($round in 1, 2) {
            & flutter test artifacts/odbc_normalizer_cache_review/bench.dart --reporter compact
            if ($LASTEXITCODE -ne 0) { throw "Benchmark round $round failed" }
            Copy-Item artifacts/odbc_normalizer_cache_review/latest.json "artifacts/odbc_normalizer_cache_review/round$round.json"
        }
    } finally { $benchShell.ProcessorAffinity = $originalAffinity }
    & artifacts/odbc_materialization_review/summarize.ps1 -EvidenceDirectory $PSScriptRoot
} finally { Pop-Location }
