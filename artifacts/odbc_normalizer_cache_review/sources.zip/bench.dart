import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:plug_agente/application/validation/query_normalizer.dart';

import 'baseline.dart' as baseline;
import 'candidate.dart' as candidate;

Object? sink;

void main() {
  test('paired normalization benchmark', () {
  final before = baseline.QueryNormalizerService(QueryNormalizer());
  final after = candidate.QueryNormalizerService(QueryNormalizer());
  final results = <Object>[];
  for (final size in [1, 1000, 10000]) {
    for (final shape in ['safe', 'rename', 'trim', 'unique']) {
      final rows = List.generate(size, (r) => <String, dynamic>{
        for (var c = 0; c < 8; c++)
          (shape == 'unique' ? 'Col $r $c' : shape == 'rename' ? 'Col $c' : 'col$c'):
            shape == 'trim' ? ' value-$r ' : r + c,
      });
      final expected = before.normalizeRows(rows);
      final actual = after.normalizeRows(rows);
      if (jsonEncode(expected) != jsonEncode(actual)) throw StateError('Rows differ');
      for (var r = 0; r < size; r++) {
        if (identical(expected[r], rows[r]) != identical(actual[r], rows[r])) {
          throw StateError('Row reuse differs');
        }
      }
      final iterations = size == 1 ? 10000 : size == 1000 ? 20 : 2;
      int measure(List<Map<String, dynamic>> Function(List<Map<String, dynamic>>) normalize) {
        final watch = Stopwatch()..start();
        for (var i = 0; i < iterations; i++) {
          sink = normalize(rows);
        }
        return watch.elapsedMicroseconds;
      }
      final samples = <Object>[];
      for (var round = -6; round < 21; round++) {
        late int b, a;
        if (round.isEven) {
          b = measure(before.normalizeRows);
          a = measure(after.normalizeRows);
        } else {
          a = measure(after.normalizeRows);
          b = measure(before.normalizeRows);
        }
        if (round >= 0) samples.add({'before_us': b, 'after_us': a});
      }
      results.add({'rows': size, 'shape': shape, 'columns': 8, 'iterations': iterations, 'samples': samples});
    }
  }
  File('artifacts/odbc_normalizer_cache_review/latest.json').writeAsStringSync(jsonEncode({'runtime': Platform.version, 'mode': 'Flutter test JIT', 'warmup': 6, 'pairs': 21, 'results': results}));
  }, timeout: const Timeout(Duration(minutes: 5)));
}
