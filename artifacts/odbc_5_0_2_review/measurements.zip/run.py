import json
import os
import shutil
import statistics
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tool.py.script_utils import import_dotenv_if_present, resolve_command
from tool.benchmarks.measurement_guard import MeasurementGuard, native_identity

import_dotenv_if_present(ROOT / '.env')
versions = ['5.0.1', '5.0.2']
identities = {}
for version in versions:
    directory = OUT / version
    directory.mkdir(exist_ok=True)
    binary = ROOT / 'build/odbc-native/packages' / version / 'windows_x64/odbc_engine.dll'
    identities[version] = native_identity(binary)
    (directory / 'pubspec.yaml').write_text(
        f'name: odbc_version_benchmark\nenvironment:\n  sdk: ^3.10.4\ndependencies:\n  odbc_fast: {version}\n'
        f'hooks:\n  user_defines:\n    odbc_fast:\n      native_library_directory: "{binary.parent.as_posix()}"\n')
    for name in ['native_odbc_benchmark.dart', 'odbc_benchmark_fixture.dart', 'validate_native_odbc_result.dart']:
        shutil.copyfile(ROOT / 'tool/benchmarks' / name, directory / name)
    with (directory / 'resolve.log').open('w') as log:
        subprocess.run(resolve_command(['dart', 'pub', 'get']), cwd=directory, stdout=log, stderr=log, check=True)
    print(f'Resolved {version}', flush=True)

records = []
with MeasurementGuard() as guard:
    for engine, mode in [('SQL Server', 'async'), ('SQL Server', 'streaming'), ('SQL Anywhere', 'streaming')]:
        key = 'ODBC_TEST_DSN_SQL_SERVER' if engine == 'SQL Server' else 'ODBC_TEST_DSN'
        dsn = os.environ.get(key)
        if not dsn:
            raise RuntimeError(f'Missing test connection for {engine}')
        for round_index, version in enumerate(['5.0.1', '5.0.2', '5.0.2', '5.0.1']):
            label = f'{engine.replace(" ", "-")}-{mode}-{round_index}-{version}'
            env = dict(os.environ)
            env['ODBC_TEST_DSN'] = dsn
            env['ODBC_FAST_NATIVE_LIBRARY'] = identities[version]['path']
            env['ODBC_BENCH_REPEATS'] = '9'
            env['ODBC_BENCH_QUERY_COUNT'] = '24'
            env.pop('ODBC_BENCH_QUERY', None)
            env.pop('ODBC_STREAM_BENCH_QUERY', None)
            print(f'Running {label}', flush=True)
            log_path = OUT / f'{label}.log'
            with log_path.open('w') as log:
                process = subprocess.run(resolve_command(['dart', 'run', 'native_odbc_benchmark.dart', '--mode', mode]),
                    cwd=OUT / version, env=env, stdout=log, stderr=log, timeout=240)
            if process.returncode:
                raise RuntimeError(f'Benchmark failed ({process.returncode}), inspect {log_path.name}')
            lines = log_path.read_text().splitlines()
            payload = next(json.loads(line) for line in reversed(lines) if line.startswith('{"benchmark"'))
            records.append({'engine': engine, 'version': version, 'round': round_index, **payload})
            (OUT / 'raw.json').write_text(json.dumps({'native': identities, 'runs': records}, indent=2))
            print(f'Passed {label}', flush=True)
    if guard.interrupted:
        raise RuntimeError('Measurement interrupted by suspension')

summary = []
for engine, mode in [('SQL Server', 'async'), ('SQL Server', 'streaming'), ('SQL Anywhere', 'streaming')]:
    selected = [r for r in records if r['engine'] == engine and r['benchmark'] == f'native_odbc_{mode}']
    for scenario in selected[0]['scenarios']:
        name = scenario['scenario']
        medians = {}
        per_run = {}
        for version in versions:
            scenarios = [s for r in selected if r['version'] == version for s in r['scenarios'] if s['scenario'] == name]
            samples = [sample['elapsed_ms'] for s in scenarios for sample in s['samples']]
            medians[version] = statistics.median(samples)
            per_run[version] = [s['elapsed_ms'] for s in scenarios]
        summary.append({'engine': engine, 'mode': mode, 'scenario': name, 'median_ms': medians,
            'run_medians_ms': per_run, 'time_reduction_pct': (1-medians['5.0.2']/medians['5.0.1'])*100})
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2), flush=True)
