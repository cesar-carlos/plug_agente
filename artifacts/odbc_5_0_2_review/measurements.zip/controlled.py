import ctypes
import hashlib
import json
import os
import random
import shutil
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / 'controlled'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT))
from tool.py.script_utils import import_dotenv_if_present, resolve_command
from tool.benchmarks.measurement_guard import MeasurementGuard, native_identity

import_dotenv_if_present(ROOT / '.env')
VERSIONS = ['5.0.1', '5.0.2']
KERNEL = ctypes.WinDLL('kernel32', use_last_error=True)
KERNEL.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
KERNEL.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
KERNEL.GetSystemTimes.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]

def cpu_times():
    idle, kernel, user = ctypes.c_ulonglong(), ctypes.c_ulonglong(), ctypes.c_ulonglong()
    if not KERNEL.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
        raise ctypes.WinError(ctypes.get_last_error())
    return idle.value, kernel.value + user.value

SERVER = '''Future<void> main() async {
  final dsn = Platform.environment['ODBC_TEST_DSN']!;
  final native = NativeOdbcConnection();
  if (!native.initialize()) throw StateError('Initialization failed');
  final connection = native.connect(dsn);
  if (connection == 0) throw StateError('Connection failed');
  final fixture = OdbcBenchmarkFixture(native, connection);
  final sharedQuery = Platform.environment['CONTROLLED_SHARED_QUERY'];
  try {
    if (sharedQuery == null) await fixture.create();
    final sql = sharedQuery ?? fixture.query;
    stdout.writeln(jsonEncode({'ready': true, 'sql': sql,
      'driver': benchmarkDriverMetadata(native, connection)}));
    await for (final line in stdin.transform(utf8.decoder).transform(const LineSplitter())) {
      final command = jsonDecode(line) as Map<String, dynamic>;
      _selectedScenario = command['scenario'] as String?;
      final results = command['mode'] == 'streaming'
        ? await _streaming(native, connection, sql) : await _async(dsn, sql);
      if (exitCode != 0) throw StateError('Benchmark validation failed');
      stdout.writeln(jsonEncode({'scenarios': results}));
    }
  } finally {
    fixture.dispose();
    native.disconnect(connection);
  }
}
String? _selectedScenario;

'''

source = (ROOT / 'tool/benchmarks/native_odbc_benchmark.dart').read_text()
imports = source[:source.index('Future<void> main')]
functions = source[source.index('int _positiveEnv'):]
functions = functions.replace('var repetition = -1;', 'var repetition = -5;')
functions = functions.replace("  ]) {\n    final async", "  ].where((spec) => _selectedScenario == null || spec.label == _selectedScenario)) {\n    final async")
functions = functions.replace("final validator = await Process.start(Platform.resolvedExecutable, [\n            'run',\n            File.fromUri(Platform.script.resolve('validate_native_odbc_result.dart')).path,\n          ]);",
    "final validator = await Process.start(File.fromUri(Platform.script.resolve('validator.exe')).path, <String>[]);")
assert 'Process.start(Platform.resolvedExecutable' not in functions
assert 'where((spec)' in functions
identities = {}
for version in VERSIONS:
    directory = OUT / version
    directory.mkdir(exist_ok=True)
    original = OUT.parent / version
    shutil.copyfile(original / 'pubspec.yaml', directory / 'pubspec.yaml')
    shutil.copyfile(original / 'pubspec.lock', directory / 'pubspec.lock')
    for name in ['odbc_benchmark_fixture.dart', 'validate_native_odbc_result.dart']:
        shutil.copyfile(ROOT / 'tool/benchmarks' / name, directory / name)
    (directory / 'controlled.dart').write_text(imports + SERVER + functions)
    binary = ROOT / 'build/odbc-native/packages' / version / 'windows_x64/odbc_engine.dll'
    identities[version] = native_identity(binary)
    shutil.copyfile(binary, directory / binary.name)
    with (directory / 'build.log').open('w') as log:
        for command in [['dart', 'pub', 'get', '--offline'],
                        ['dart', 'compile', 'exe', 'controlled.dart', '-o', 'controlled.exe'],
                        ['dart', 'compile', 'exe', 'validate_native_odbc_result.dart', '-o', 'validator.exe']]:
            subprocess.run(resolve_command(command), cwd=directory, stdout=log, stderr=log, check=True)
    print(f'Compiled and verified {version}', flush=True)

def start(version, dsn, query=None):
    directory = OUT / version
    env = dict(os.environ)
    env['ODBC_TEST_DSN'] = dsn
    env['ODBC_BENCH_REPEATS'] = '7'
    env['ODBC_BENCH_QUERY_COUNT'] = '24'
    env['ODBC_STREAM_BENCH_FETCH_SIZE'] = '1000'
    env['ODBC_STREAM_BENCH_CHUNK_SIZE'] = '1048576'
    if query is not None:
        env['CONTROLLED_SHARED_QUERY'] = query
    errors = (directory / 'stderr.log').open('a')
    process = subprocess.Popen([str(directory / 'controlled.exe')], cwd=directory, env=env,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors, text=True, bufsize=1)
    if not KERNEL.SetProcessAffinityMask(int(process._handle), 255):
        raise ctypes.WinError(ctypes.get_last_error())
    if not KERNEL.SetPriorityClass(int(process._handle), 0x8000):
        raise ctypes.WinError(ctypes.get_last_error())
    return process, read(process), errors

def read(process):
    line = process.stdout.readline()
    if not line:
        raise RuntimeError(f'Benchmark exited {process.poll()}, inspect stderr.log')
    return json.loads(line)

records = []
metadata = {'native': identities, 'affinity_mask': 255, 'priority': 'above_normal',
    'warmup_batches_per_call': 5, 'samples_per_call': 7, 'pairs': 8, 'query_count': 24,
    'source_sha256': hashlib.sha256((imports + SERVER + functions).encode()).hexdigest(),
    'shared_fixture': True, 'mode': 'AOT', 'drivers': {}}
randomizer = random.Random(502)
with MeasurementGuard() as guard:
    for engine, key in [('SQL Server', 'ODBC_TEST_DSN_SQL_SERVER'), ('SQL Anywhere', 'ODBC_TEST_DSN')]:
        clients = {}
        try:
            base, ready, errors = start('5.0.1', os.environ[key])
            clients['5.0.1'] = (base, errors)
            candidate, candidate_ready, errors = start('5.0.2', os.environ[key], ready['sql'])
            clients['5.0.2'] = (candidate, errors)
            if ready['driver'] != candidate_ready['driver']:
                raise RuntimeError('Driver mismatch')
            metadata['drivers'][engine] = ready['driver']
            scenarios = ['workerCount=1', 'workerCount=4', 'workerCount=4 columnar',
                         'workerCount=4 columnar compressed', 'native pool', 'prepared reuse']
            if engine == 'SQL Anywhere':
                scenarios = ['workerCount=4', 'workerCount=4 columnar', 'workerCount=4 columnar compressed']
            scenarios.append('streaming')
            for pair in range(8):
                sequence = scenarios.copy()
                randomizer.shuffle(sequence)
                for scenario in sequence:
                    versions = VERSIONS if pair % 2 == 0 else list(reversed(VERSIONS))
                    for version in versions:
                        process = clients[version][0]
                        before = cpu_times()
                        started = time.monotonic()
                        command = {'mode': 'streaming' if scenario == 'streaming' else 'async',
                                   'scenario': None if scenario == 'streaming' else scenario}
                        process.stdin.write(json.dumps(command) + '\n')
                        process.stdin.flush()
                        result = read(process)
                        after = cpu_times()
                        busy = 100 * (1 - (after[0]-before[0])/(after[1]-before[1]))
                        records.append({'engine': engine, 'pair': pair, 'version': version,
                            'wall_s': time.monotonic()-started, 'system_cpu_pct': busy, **result})
                        (OUT / 'raw.json').write_text(json.dumps({'metadata': metadata, 'records': records}, indent=2))
                print(f'{engine}: paired round {pair+1}/8 complete', flush=True)
        finally:
            for version in reversed(VERSIONS):
                if version in clients:
                    process, errors = clients[version]
                    process.stdin.close()
                    if process.wait(timeout=30) != 0:
                        raise RuntimeError(f'Cleanup failed for {version}')
                    errors.close()
    if guard.interrupted:
        raise RuntimeError('Suspension invalidated measurements')
print('All measurements and cleanup passed', flush=True)
