import 'dart:convert';
import 'package:odbc_fast/odbc_fast.dart';

int sink = 0;

void prepare(String sql, Map<String, dynamic> parameters, bool copy) {
  final parsed = NamedParameterParser.extract(sql);
  final positional = NamedParameterParser.toPositionalParams(
    namedParams: copy ? Map<String, Object?>.from(parameters) : parameters,
    paramNames: parsed.paramNames,
  );
  sink += positional.length;
}

void main() {
  final output = <Map<String, Object>>[];
  for (final count in [1, 16, 64]) {
    final parameters = <String, dynamic>{for (var i = 0; i < count; i++) 'p$i': i};
    final sql = 'SELECT ${parameters.keys.map((key) => ':$key').join(', ')}';
    for (var i = 0; i < 20000; i++) {
      prepare(sql, parameters, true);
      prepare(sql, parameters, false);
    }
    final samples = <String, List<double>>{'before': [], 'after': []};
    const iterations = 100000;
    for (var round = 0; round < 15; round++) {
      for (final copy in round.isEven ? [true, false] : [false, true]) {
        final timer = Stopwatch()..start();
        for (var i = 0; i < iterations; i++) {
          prepare(sql, parameters, copy);
        }
        timer.stop();
        samples[copy ? 'before' : 'after']!.add(timer.elapsedMicroseconds / iterations);
      }
    }
    output.add({'parameters': count, 'iterations_per_sample': iterations, 'samples_us_per_call': samples});
  }
  print(jsonEncode({'sink': sink, 'scenarios': output}));
}
