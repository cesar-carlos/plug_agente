import ctypes
import json
import os
import subprocess
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT))
from tool.py.script_utils import import_dotenv_if_present
from tool.benchmarks.measurement_guard import MeasurementGuard

import_dotenv_if_present(ROOT / '.env')
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
kernel.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
kernel.GetProcessTimes.argtypes = [ctypes.c_void_p] * 5
counter_script = '''$ErrorActionPreference='Stop'; while ($null -ne [Console]::ReadLine()) {
  $r = @(Get-CimInstance Win32_PerfRawData_PerfProc_Process -Filter "Name='sqlservr' OR Name LIKE 'dbsrv16%'" |
    Select-Object Name,IDProcess,PercentProcessorTime)
  [Console]::WriteLine((ConvertTo-Json -InputObject $r -Compress))
}'''
counter_process = subprocess.Popen(['powershell', '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', counter_script],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1, creationflags=0x08000000)

def database_time(engine):
    counter_process.stdin.write('sample\n')
    counter_process.stdin.flush()
    line = counter_process.stdout.readline()
    if not line:
        raise RuntimeError('Database CPU counter unavailable')
    counters = json.loads(line)
    prefix = 'sqlservr' if engine == 'SQL Server' else 'dbsrv16'
    selected = [c for c in counters if c['Name'].startswith(prefix)]
    if not selected:
        raise RuntimeError('Expected database CPU counter missing')
    return sum(c['PercentProcessorTime'] for c in selected)

def system_times():
    idle, kern, user = ctypes.c_ulonglong(), ctypes.c_ulonglong(), ctypes.c_ulonglong()
    if not kernel.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user)):
        raise ctypes.WinError(ctypes.get_last_error())
    return idle.value, kern.value + user.value

def process_time(process):
    return handle_time(int(process._handle))

def handle_time(handle):
    values = [ctypes.c_ulonglong() for _ in range(4)]
    if not kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in values]):
        raise ctypes.WinError(ctypes.get_last_error())
    return values[2].value + values[3].value

def wait_quiet():
    stable = 0
    for attempt in range(60):
        before = system_times()
        time.sleep(1)
        after = system_times()
        busy = 100 * (1-(after[0]-before[0])/(after[1]-before[1]))
        stable = stable + 1 if busy <= 15 else 0
        if stable == 2:
            return
    raise RuntimeError('No quiet window below 15% CPU for two seconds within 60 seconds')

def read(process):
    line = process.stdout.readline()
    if not line:
        raise RuntimeError('Benchmark exited unexpectedly; inspect quiet stderr')
    return json.loads(line)

def start(version, dsn, query=None):
    directory = OUT / version
    env = dict(os.environ)
    env.update(ODBC_TEST_DSN=dsn, ODBC_BENCH_REPEATS='15', ODBC_BENCH_QUERY_COUNT='48',
               ODBC_STREAM_BENCH_FETCH_SIZE='1000', ODBC_STREAM_BENCH_CHUNK_SIZE='1048576')
    if query:
        env['CONTROLLED_SHARED_QUERY'] = query
    errors = (directory / 'quiet-stderr.log').open('a')
    p = subprocess.Popen([str(directory / 'controlled.exe')], cwd=directory, env=env,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors, text=True, bufsize=1)
    if not kernel.SetProcessAffinityMask(int(p._handle), 255) or not kernel.SetPriorityClass(int(p._handle), 0x8000):
        raise ctypes.WinError(ctypes.get_last_error())
    return p, read(p), errors

records, attempts = [], []
output = {'records': records, 'attempts': attempts, 'external_cpu_limit_pct': 15,
          'idle_cpu_limit_pct': 15, 'samples_per_call': 15, 'query_count': 48, 'pairs': 8,
          'database_cpu_source': 'Win32_PerfRawData_PerfProc_Process', 'database_cpu_excluded_from_external_load': True}
def save():
    (OUT / 'quiet2-raw.json').write_text(json.dumps(output, indent=2))

with MeasurementGuard() as guard:
    try:
        for engine, key, scenarios in [
            ('SQL Server', 'ODBC_TEST_DSN_SQL_SERVER', ['workerCount=4', 'workerCount=4 columnar',
                 'workerCount=4 columnar compressed', 'native pool']),
            ('SQL Anywhere', 'ODBC_TEST_DSN', ['workerCount=4', 'workerCount=4 columnar'])]:
            clients = {}
            try:
                p, ready, errors = start('5.0.1', os.environ[key])
                clients['5.0.1'] = (p, errors)
                p, ready2, errors = start('5.0.2', os.environ[key], ready['sql'])
                clients['5.0.2'] = (p, errors)
                if ready['driver'] != ready2['driver']:
                    raise RuntimeError('Driver mismatch')
                for pair in range(8):
                    sequence = scenarios[pair % len(scenarios):] + scenarios[:pair % len(scenarios)]
                    for scenario in sequence:
                        for attempt in range(4):
                            wait_quiet()
                            current = []
                            order = ['5.0.1', '5.0.2'] if pair % 2 == 0 else ['5.0.2', '5.0.1']
                            for version in order:
                                process = clients[version][0]
                                db_before = database_time(engine)
                                before, cpu_before = system_times(), process_time(process)
                                process.stdin.write(json.dumps({'mode': 'async', 'scenario': scenario}) + '\n')
                                process.stdin.flush()
                                result = read(process)
                                after, cpu_after = system_times(), process_time(process)
                                db_after = database_time(engine)
                                total = after[1]-before[1]
                                busy = total-(after[0]-before[0])
                                external = max(0, 100*(busy-(cpu_after-cpu_before)-(db_after-db_before))/total)
                                current.append({'engine': engine, 'pair': pair, 'attempt': attempt,
                                    'version': version, 'system_cpu_pct': busy*100/total,
                                    'database_cpu_pct': 100*(db_after-db_before)/total,
                                    'external_cpu_estimate_pct': external, **result})
                            accepted = all(r['external_cpu_estimate_pct'] <= 15 for r in current)
                            attempts.append({'engine': engine, 'pair': pair, 'scenario': scenario,
                                'attempt': attempt, 'accepted': accepted, 'measurements': current})
                            if accepted:
                                records.extend(current)
                            save()
                            if accepted:
                                break
                            print(f'Rejected load-contaminated pair: {engine} {scenario}', flush=True)
                        else:
                            raise RuntimeError('Four contaminated attempts for one pair; dedicated idle host required')
                    print(f'Quiet {engine}: round {pair+1}/8 passed', flush=True)
            finally:
                for version in ['5.0.2', '5.0.1']:
                    if version in clients:
                        p, errors = clients[version]
                        p.stdin.close()
                        if p.wait(timeout=30) != 0:
                            raise RuntimeError('Fixture cleanup failed')
                        errors.close()
        if guard.interrupted:
            raise RuntimeError('Suspension invalidated run')
        output['complete'] = True
    except Exception as error:
        output['complete'] = False
        output['failure'] = str(error)
        raise
    finally:
        save()
        counter_process.stdin.close()
        counter_process.wait(timeout=15)
print('Quiet comparison and cleanup completed', flush=True)
