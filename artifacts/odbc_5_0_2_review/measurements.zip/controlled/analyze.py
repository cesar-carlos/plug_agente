import json
import math
import statistics
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
quiet = '--quiet' in sys.argv
raw = json.loads((root / ('quiet2-raw.json' if quiet else 'raw.json')).read_text())
if quiet and not raw.get('complete'):
    raise ValueError('Quiet comparison did not complete')
groups = {}
for record in raw['records']:
    for scenario in record['scenarios']:
        key = (record['engine'], scenario['scenario'])
        groups.setdefault(key, {}).setdefault(record['pair'], {})[record['version']] = statistics.median(
            sample['elapsed_ms'] for sample in scenario['samples'])
summary = []
for (engine, scenario), pairs in groups.items():
    if len(pairs) != 8 or any(set(pair) != {'5.0.1', '5.0.2'} for pair in pairs.values()):
        raise ValueError('Incomplete paired experiment')
    ratios = [math.log(pair['5.0.2'] / pair['5.0.1']) for pair in pairs.values()]
    average = statistics.mean(ratios)
    margin = 2.364624251 * statistics.stdev(ratios) / math.sqrt(len(ratios))
    low, high = [(math.exp(value)-1)*100 for value in (average-margin, average+margin)]
    effect = (math.exp(average)-1)*100
    classification = ('improvement' if high < -5 else 'regression' if low > 5
                      else 'within_5_percent' if low >= -5 and high <= 5 else 'inconclusive')
    summary.append({'engine': engine, 'scenario': scenario,
        'baseline_median_ms': statistics.median(p['5.0.1'] for p in pairs.values()),
        'candidate_median_ms': statistics.median(p['5.0.2'] for p in pairs.values()),
        'paired_time_change_pct': effect, 'approx_95_ci_pct': [low, high],
        'candidate_faster_pairs': sum(value < 0 for value in ratios),
        'pairs': pairs, 'classification': classification})
cpu = [r['system_cpu_pct'] for r in raw['records']]
output = {'method': 'Paired log time ratios of per-run medians, Student t df=7, exploratory 95% intervals',
    'practical_threshold_pct': 5, 'system_cpu_pct': {'min': min(cpu), 'median': statistics.median(cpu), 'max': max(cpu)},
    'limitations': ['Shared Windows host, no exclusive CPU or database reservation',
                   'CPU affinity and priority constrain benchmark scheduling but do not isolate other workloads',
                   'Intervals are exploratory and not adjusted for multiple comparisons',
                   'Component benchmark, not full Flutter/Hub latency'],
    'results': summary}
if quiet:
    external = [r['external_cpu_estimate_pct'] for r in raw['records']]
    output['external_cpu_pct'] = {'min': min(external), 'mean': statistics.mean(external), 'max': max(external)}
    output['accepted_pairs'] = sum(a['accepted'] for a in raw['attempts'])
    output['rejected_pairs'] = sum(not a['accepted'] for a in raw['attempts'])
    output['load_filter'] = 'Below 15% idle CPU for two seconds, at most 15% external CPU during each paired measurement; local database CPU excluded'
(root / ('quiet-summary.json' if quiet else 'summary.json')).write_text(json.dumps(output, indent=2))
for row in summary:
    print(f"{row['engine']} | {row['scenario']} | {row['paired_time_change_pct']:+.1f}% | "
          f"CI [{row['approx_95_ci_pct'][0]:+.1f}, {row['approx_95_ci_pct'][1]:+.1f}] | "
          f"faster {row['candidate_faster_pairs']}/8 | {row['classification']}")
print('CPU', output['system_cpu_pct'])
