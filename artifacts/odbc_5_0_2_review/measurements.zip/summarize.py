import json
import statistics
from pathlib import Path

out = Path(__file__).resolve().parent
runs = json.loads((out / 'aot-raw.json').read_text())
summary = []
for scenario in runs[0]['scenarios']:
    label = scenario['scenario']
    medians = {}
    run_medians = {}
    for version in ['5.0.1', '5.0.2']:
        selected = [s for r in runs if r['version'] == version for s in r['scenarios'] if s['scenario'] == label]
        medians[version] = statistics.median([p['elapsed_ms'] for s in selected for p in s['samples']])
        run_medians[version] = [s['elapsed_ms'] for s in selected]
    summary.append({'scenario': label, 'median_ms': medians, 'run_medians_ms': run_medians,
                    'time_change_pct': (medians['5.0.2'] / medians['5.0.1'] - 1) * 100})
micro = json.loads((out / '5.0.2/parameter-copy-aot.json').read_text())
micro_summary = []
for scenario in micro['scenarios']:
    before = statistics.median(scenario['samples_us_per_call']['before'])
    after = statistics.median(scenario['samples_us_per_call']['after'])
    micro_summary.append({'parameters': scenario['parameters'], 'before_us': before, 'after_us': after,
                          'time_reduction_pct': (1-after/before)*100})
result = {'aot_native': summary, 'aot_parameter_copy': micro_summary,
          'limitations': ['Local component benchmark, not full Flutter/Hub round trip',
                         'Two independent runs per version; 15 samples per AOT run',
                         'Compressed native scenario measured only in JIT',
                         'External machine/database load was not controlled']}
(out / 'final-summary.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
