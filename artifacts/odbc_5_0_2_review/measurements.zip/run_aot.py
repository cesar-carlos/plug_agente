import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tool.py.script_utils import import_dotenv_if_present, resolve_command
from tool.benchmarks.measurement_guard import MeasurementGuard
from tool.benchmarks.measurement_guard import native_identity

import_dotenv_if_present(ROOT / '.env')
for version in ['5.0.1', '5.0.2']:
    directory = OUT / version
    binary = ROOT / 'build/odbc-native/packages' / version / 'windows_x64/odbc_engine.dll'
    native_identity(binary)
    shutil.copyfile(binary, directory / 'odbc_engine.dll')
    source = (directory / 'native_odbc_benchmark.dart').read_text()
    # The compressed case starts its decoder through Platform.resolvedExecutable,
    # which is this benchmark executable in AOT rather than the Dart CLI.
    source = source.replace("    (label: 'workerCount=4 columnar compressed', workers: 4, encoding: ResultEncoding.columnarCompressed),\n", '')
    (directory / 'native_aot.dart').write_text(source)
    with (directory / 'compile.log').open('w') as log:
        subprocess.run(resolve_command(['dart', 'compile', 'exe', 'native_aot.dart', '-o', 'native_aot.exe']),
                       cwd=directory, stdout=log, stderr=log, check=True)
    print(f'Compiled {version}', flush=True)
records = []
with MeasurementGuard() as guard:
    for index, version in enumerate(['5.0.2', '5.0.1', '5.0.1', '5.0.2']):
        directory = OUT / version
        env = dict(os.environ)
        env['ODBC_TEST_DSN'] = env['ODBC_TEST_DSN_SQL_SERVER']
        env['ODBC_BENCH_REPEATS'] = '15'
        env['ODBC_BENCH_QUERY_COUNT'] = '24'
        env.pop('ODBC_BENCH_QUERY', None)
        print(f'Running AOT {index} {version}', flush=True)
        log_path = OUT / f'aot-{index}-{version}.log'
        with log_path.open('w') as log:
            subprocess.run([str(directory / 'native_aot.exe'), '--mode', 'async'], cwd=directory,
                           env=env, stdout=log, stderr=log, check=True, timeout=120)
        payload = next(json.loads(line) for line in reversed(log_path.read_text().splitlines()) if line.startswith('{"benchmark"'))
        records.append({'version': version, 'round': index, **payload})
        (OUT / 'aot-raw.json').write_text(json.dumps(records, indent=2))
        print(f'Passed AOT {index} {version}', flush=True)
    if guard.interrupted:
        raise RuntimeError('Measurement interrupted')
