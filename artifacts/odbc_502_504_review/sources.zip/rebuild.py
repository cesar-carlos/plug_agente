"""Extract sources.zip into build/odbc-502-504-review, then run this file."""
import json, shutil, subprocess
from pathlib import Path

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
DART='C:/Users/cesar/dev/flutter/bin/cache/dart-sdk/bin/dart.exe'
for version in ['5.0.2','5.0.4']:
    directory=WORK/version
    directory.mkdir(exist_ok=True)
    native=ROOT/'build/odbc-native/packages'/version/'windows_x64'
    if not (native/'manifest.json').is_file():
        raise RuntimeError('Prepare the verified published native package '+version+' first')
    (directory/'pubspec.yaml').write_text(
        f'name: odbc_version_benchmark\nenvironment:\n  sdk: ^3.10.4\ndependencies:\n  odbc_fast: {version}\n'
        f'hooks:\n  user_defines:\n    odbc_fast:\n      native_library_directory: "{native.as_posix()}"\n')
    for name in ['controlled.dart','odbc_benchmark_fixture.dart','validate_native_odbc_result.dart']:
        shutil.copyfile(WORK/name,directory/name)
    shutil.copyfile(native/'odbc_engine.dll',directory/'odbc_engine.dll')
    with (directory/'build.log').open('w') as log:
        for args in [['pub','get','--offline'],['compile','exe','controlled.dart','-o','controlled.exe'],
                     ['compile','exe','validate_native_odbc_result.dart','-o','validator.exe']]:
            subprocess.run([DART,*args],cwd=directory,stdout=log,stderr=log,check=True)
def identity(version):
    config=json.loads((WORK/version/'.dart_tool/package_config.json').read_text())
    return {p['name']:p['rootUri'] for p in config['packages'] if p['name']!='odbc_version_benchmark'}
a,b=identity('5.0.2'),identity('5.0.4')
assert {k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}=={'odbc_fast'}
print('AOT rebuild verified; run.py performs measurements and creates disposable benchmark tables.')
