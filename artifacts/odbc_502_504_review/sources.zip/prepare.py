import hashlib, json, shutil, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DART = 'C:/Users/cesar/dev/flutter/bin/cache/dart-sdk/bin/dart.exe'
source = (ROOT / 'build/odbc-version-benchmark/controlled/5.0.2/controlled.dart').read_text()
source = source.replace('var repetition = -5;', 'var repetition = -3;')
# Validate every cleanup result as well as query output.
source = source.replace('if (statement != 0) await async.closeStatement(statement);',
    "if (statement != 0 && !await async.closeStatement(statement)) throw StateError('Statement cleanup failed');")
source = source.replace('await async.disconnect(connection);',
    "if (!await async.disconnect(connection)) throw StateError('Connection cleanup failed');")
source = source.replace('if (pool != 0) await async.poolClose(pool);',
    "if (pool != 0 && !await async.poolClose(pool)) throw StateError('Pool cleanup failed');")
source = source.replace('native.disconnect(connection);',
    "if (!native.disconnect(connection)) throw StateError('Fixture disconnect failed');")
(WORK / 'controlled.dart').write_text(source)
for name in ['odbc_benchmark_fixture.dart', 'validate_native_odbc_result.dart']:
    shutil.copyfile(ROOT / 'tool/benchmarks' / name, WORK / name)
for version in ['5.0.2', '5.0.4']:
    directory = WORK / version
    directory.mkdir(exist_ok=True)
    binary_dir = ROOT / 'build/odbc-native/packages' / version / 'windows_x64'
    (directory / 'pubspec.yaml').write_text(
        f'name: odbc_version_benchmark\nenvironment:\n  sdk: ^3.10.4\ndependencies:\n  odbc_fast: {version}\n'
        f'hooks:\n  user_defines:\n    odbc_fast:\n      native_library_directory: "{binary_dir.as_posix()}"\n')
    shutil.copyfile(ROOT / 'build/odbc-version-benchmark/5.0.2/pubspec.lock', directory / 'pubspec.lock')
    for name in ['controlled.dart', 'odbc_benchmark_fixture.dart', 'validate_native_odbc_result.dart']:
        shutil.copyfile(WORK / name, directory / name)
    shutil.copyfile(binary_dir / 'odbc_engine.dll', directory / 'odbc_engine.dll')
    with (directory / 'build.log').open('w') as log:
        for args in [['pub', 'get', '--offline'], ['compile', 'exe', 'controlled.dart', '-o', 'controlled.exe'],
                     ['compile', 'exe', 'validate_native_odbc_result.dart', '-o', 'validator.exe']]:
            subprocess.run([DART, *args], cwd=directory, stdout=log, stderr=log, check=True)
    print('Compiled', version, flush=True)
def dependency_identity(version):
    config = json.loads((WORK/version/'.dart_tool/package_config.json').read_text())
    return {p['name']:p['rootUri'] for p in config['packages'] if p['name'] != 'odbc_version_benchmark'}
a,b = [dependency_identity(v) for v in ['5.0.2','5.0.4']]
assert {k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)} == {'odbc_fast'}
(WORK / 'dependencies.json').write_text(json.dumps({'5.0.2':a,'5.0.4':b},indent=2))
print('Only odbc_fast differs; both AOT executables ready', flush=True)
