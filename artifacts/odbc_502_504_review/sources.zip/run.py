import ctypes, hashlib, json, os, queue, random, statistics, subprocess, sys, threading, time
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
OUT = ROOT / 'artifacts/odbc_502_504_review'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
from tool.py.script_utils import import_dotenv_if_present
from tool.benchmarks.measurement_guard import MeasurementGuard, native_identity
import_dotenv_if_present(ROOT / '.env')
VERSIONS = ['5.0.2', '5.0.4']
SCENARIOS = ['workerCount=4', 'workerCount=4 columnar', 'workerCount=4 columnar compressed',
             'native pool', 'prepared reuse', 'streaming']
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
kernel.GetSystemTimes.argtypes = [ctypes.c_void_p]*3
def cpu_times():
    idle,kern,user = (ctypes.c_ulonglong() for _ in range(3))
    if not kernel.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kern),ctypes.byref(user)):
        raise ctypes.WinError(ctypes.get_last_error())
    return idle.value, kern.value+user.value
def busy(a,b):
    return max(0, min(100, 100*(1-(b[0]-a[0])/(b[1]-a[1]))))
def quiet():
    samples=[]
    for _ in range(20):
        a=cpu_times(); time.sleep(1); samples.append(busy(a,cpu_times()))
        if len(samples)>=2 and max(samples[-2:])<=15:
            return samples
    raise RuntimeError('No two-second idle window below 15% CPU within 20 seconds')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
class Client:
    def __init__(self, version, dsn, query=None):
        self.version=version
        directory=WORK/version
        env=dict(os.environ)
        env.update(ODBC_TEST_DSN=dsn, ODBC_BENCH_REPEATS='9', ODBC_BENCH_QUERY_COUNT='24',
                   ODBC_STREAM_BENCH_FETCH_SIZE='1000',ODBC_STREAM_BENCH_CHUNK_SIZE='1048576')
        env.pop('CONTROLLED_SHARED_QUERY',None)
        if query: env['CONTROLLED_SHARED_QUERY']=query
        self.errors=(directory/'stderr.log').open('a')
        self.p=subprocess.Popen([str(directory/'controlled.exe')],cwd=directory,env=env,
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.errors,text=True,bufsize=1)
        if not kernel.SetProcessAffinityMask(int(self.p._handle),255):
            raise ctypes.WinError(ctypes.get_last_error())
        self.messages=queue.Queue()
        def reader():
            for line in self.p.stdout: self.messages.put(line)
            self.messages.put(None)
        threading.Thread(target=reader,daemon=True).start()
    def read(self):
        line=self.messages.get(timeout=180)
        if not line: raise RuntimeError('Benchmark process exited; inspect local stderr')
        return json.loads(line)
    def call(self,scenario):
        stop=threading.Event(); cpu=[]
        def monitor():
            previous=cpu_times()
            while not stop.wait(.25):
                current=cpu_times(); cpu.append(busy(previous,current)); previous=current
        thread=threading.Thread(target=monitor,daemon=True); thread.start()
        before=cpu_times(); started=time.monotonic()
        try:
            self.p.stdin.write(json.dumps({'mode':'streaming' if scenario=='streaming' else 'async',
                'scenario':None if scenario=='streaming' else scenario})+'\n'); self.p.stdin.flush()
            result=self.read()
        finally:
            elapsed=time.monotonic()-started; after=cpu_times(); stop.set(); thread.join()
        return {'version':self.version,'wall_seconds':elapsed,'cpu_mean_pct':busy(before,after),
                'cpu_samples_pct':cpu,**result}
    def close(self):
        self.p.stdin.close()
        code=self.p.wait(timeout=30); self.errors.close()
        if code: raise RuntimeError('Benchmark fixture/connection cleanup failed')

metadata={'versions':VERSIONS,'runtime':'Dart AOT','dart':subprocess.check_output(
    ['C:/Users/cesar/dev/flutter/bin/cache/dart-sdk/bin/dart.exe','--version'],text=True).strip(),
    'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'logical_processors':os.cpu_count(),'affinity_mask':255,'priority':'normal',
    'warmups_per_call':3,'samples_per_call':9,'queries_per_async_sample':24,'rows_per_query':8000,
    'rounds':2,'pairs_per_round':3,'idle_limit_pct':15,'mean_cpu_limit_pct':35,
    'peak_cpu_limit_pct':65,'pair_cpu_difference_limit_pct_points':8,
    'load_note':'Other tasks could not be paused; total host CPU includes database and benchmark. CPU filter does not exclude disk/network/server contention.',
    'workload':'Existing deterministic_8000_rows_v1, shared unique disposable fixture per engine',
    'timing_scope':'Native async encode/copy/worker/pool or streaming parse; async row validation outside timing; no Hub transport or full agent gateway',
    'native':{v:native_identity(ROOT/'build/odbc-native/packages'/v/'windows_x64/odbc_engine.dll') for v in VERSIONS},
    'sources':{name:sha(WORK/name) for name in ['controlled.dart','odbc_benchmark_fixture.dart','validate_native_odbc_result.dart','run.py','prepare.py']},
    'executables':{v:{name:sha(WORK/v/name) for name in ['controlled.exe','validator.exe','odbc_engine.dll','pubspec.lock']} for v in VERSIONS}}
report={'metadata':metadata,'attempts':[],'complete':False,'cleanup':{}}
def save(): (OUT/'raw.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def pair(clients,scenario,order,context):
    for attempt in range(2):
        idle=quiet()
        values=[clients[v].call(scenario) for v in order]
        accepted=(all(v['cpu_mean_pct']<=35 and max(v['cpu_samples_pct'],default=0)<=65 for v in values)
                  and abs(values[0]['cpu_mean_pct']-values[1]['cpu_mean_pct'])<=8)
        report['attempts'].append({**context,'scenario':scenario,'attempt':attempt,'idle_cpu_samples_pct':idle,
                                   'accepted':accepted,'measurements':values}); save()
        if accepted: return
        print('Rejected CPU-contaminated pair',context,scenario,flush=True)
    raise RuntimeError('Two contaminated pairs; controlled comparison requires a quieter window')

save()
with MeasurementGuard() as guard:
    try:
        quiet()
        for engine,key in [('SQL Server','ODBC_TEST_DSN_SQL_SERVER'),('SQL Anywhere','ODBC_TEST_DSN')]:
            if not os.environ.get(key): raise RuntimeError('Missing test DSN for '+engine)
            clients={}
            try:
                base=Client(VERSIONS[0],os.environ[key]); clients[VERSIONS[0]]=base; ready=base.read()
                candidate=Client(VERSIONS[1],os.environ[key],ready['sql']); clients[VERSIONS[1]]=candidate
                ready2=candidate.read()
                if ready['driver']!=ready2['driver']: raise RuntimeError('Driver identity mismatch')
                report.setdefault('drivers',{})[engine]=ready['driver']; save()
                # Same-code A/A controls bracket all A/B rounds for each scenario.
                for phase in ['before','after']:
                    if phase=='after':
                        for round_id in range(2):
                            for pair_id in range(3):
                                scenarios=SCENARIOS.copy(); random.Random(504+round_id*3+pair_id).shuffle(scenarios)
                                for scenario in scenarios:
                                    order=VERSIONS if (round_id*3+pair_id)%2==0 else VERSIONS[::-1]
                                    pair(clients,scenario,order,{'engine':engine,'kind':'AB','round':round_id,'pair':pair_id})
                                print(engine,'round',round_id+1,'pair',pair_id+1,'complete',flush=True)
                    for scenario in SCENARIOS:
                        pair(clients,scenario,[VERSIONS[0],VERSIONS[0]],{'engine':engine,'kind':'AA','phase':phase})
                    print(engine,'A/A',phase,'complete',flush=True)
            finally:
                for version in VERSIONS[::-1]:
                    if version in clients:
                        clients[version].close(); report['cleanup'][engine+' '+version]='passed'; save()
        if guard.interrupted: raise RuntimeError('Suspension invalidated measurement')
        report['complete']=True
    except Exception as error:
        report['failure']=str(error); print('INCONCLUSIVE:',error,flush=True)
    finally:
        report['largest_heartbeat_gap_seconds']=guard.largest_gap_seconds
        report['sources_unchanged']=all(sha(WORK/name)==digest for name,digest in metadata['sources'].items())
        save()
print('Measurement complete:',report['complete'],flush=True)
