$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Push-Location $repoRoot
try {
    & dart compile exe artifacts/odbc_materialization_review/bench.dart -o build/odbc_materialization_bench.exe
    if ($LASTEXITCODE -ne 0) { throw 'Benchmark compilation failed' }
    $benchShell = Get-Process -Id $PID
    $originalAffinity = $benchShell.ProcessorAffinity
    try {
        $benchShell.ProcessorAffinity = 4
        foreach ($round in 1, 2) {
            & .\build\odbc_materialization_bench.exe | Set-Content "artifacts/odbc_materialization_review/round$round.json"
            if ($LASTEXITCODE -ne 0) { throw "Benchmark round $round failed" }
        }
    } finally { $benchShell.ProcessorAffinity = $originalAffinity }
    & "$PSScriptRoot/summarize.ps1"
} finally { Pop-Location }
