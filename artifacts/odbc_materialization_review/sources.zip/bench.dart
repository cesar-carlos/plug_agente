import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:odbc_fast/odbc_fast.dart';

import 'baseline.dart' as baseline;
import 'candidate.dart' as candidate;

int sink = 0;

bool scan(List<Map<String, Object?>> rows, bool Function(Object?) needs) {
  for (final row in rows) {
    for (final value in row.values) {
      if (needs(value)) return true;
    }
  }
  return false;
}

void main() {
  final results = <Object>[];
  final special = <Object?>[
    DateTime.utc(2026),
    LazyString(Uint8List.fromList([65, 66])),
    Uint8List.fromList([0, 255]),
    <int>[1, 2],
    <Object?>[1, 'x'],
    <String, Object?>{'x': 1},
  ];
  for (final size in [1, 1000, 10000]) {
    for (final shape in ['plain', 'text', 'numbers', 'special_first', 'special_last', 'objects']) {
      final rows = List.generate(size, (r) => <String, Object?>{
        for (var c = 0; c < 8; c++) 'c$c': switch (shape) {
          'text' => 'value-$r-$c',
          'numbers' => r + c / 10,
          'objects' => special[4 + c % 2],
          _ => switch (c % 4) { 0 => null, 1 => 'value-$r', 2 => r, _ => true },
        },
      });
      if (shape == 'special_first') rows.first['c0'] = special[0];
      if (shape == 'special_last') rows.last['c7'] = special[2];
      for (final value in [...special, null, 'x', 1, 1.5, true]) {
        if (baseline.odbcWireCellNeedsMaterialization(value) != candidate.odbcWireCellNeedsMaterialization(value)) {
          throw StateError('Cell equivalence failed');
        }
      }
      final expected = scan(rows, baseline.odbcWireCellNeedsMaterialization);
      if (expected != scan(rows, candidate.odbcWireCellNeedsMaterialization)) {
        throw StateError('Scan equivalence failed');
      }
      final iterations = shape == 'special_first' ? 100000 : (100000 ~/ size);
      int measure(bool Function(Object?) needs) {
        final watch = Stopwatch()..start();
        for (var i = 0; i < iterations; i++) {
          if (scan(rows, needs)) sink++;
        }
        return watch.elapsedMicroseconds;
      }
      final samples = <Object>[];
      for (var round = -6; round < 21; round++) {
        late int before, after;
        if (round.isEven) {
          before = measure(baseline.odbcWireCellNeedsMaterialization);
          after = measure(candidate.odbcWireCellNeedsMaterialization);
        } else {
          after = measure(candidate.odbcWireCellNeedsMaterialization);
          before = measure(baseline.odbcWireCellNeedsMaterialization);
        }
        if (round >= 0) samples.add({'before_us': before, 'after_us': after});
      }
      results.add({'rows': size, 'columns': 8, 'shape': shape, 'iterations': iterations, 'samples': samples});
    }
  }
  stdout.writeln(jsonEncode({'runtime': Platform.version, 'mode': 'AOT', 'warmup': 6, 'pairs': 21, 'sink': sink, 'results': results}));
}
