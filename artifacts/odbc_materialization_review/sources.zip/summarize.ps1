param([string]$EvidenceDirectory = $PSScriptRoot)
$summary = foreach ($round in 1, 2) {
    $data = Get-Content -LiteralPath (Join-Path $EvidenceDirectory "round$round.json") -Raw | ConvertFrom-Json
    foreach ($case in $data.results) {
        $before = @($case.samples.before_us | Sort-Object)
        $after = @($case.samples.after_us | Sort-Object)
        [pscustomobject]@{
            round = $round
            rows = $case.rows
            shape = $case.shape
            iterations = $case.iterations
            before_median_us = $before[10] / $case.iterations
            after_median_us = $after[10] / $case.iterations
            before_p10_us = $before[2] / $case.iterations
            before_p90_us = $before[18] / $case.iterations
            after_p10_us = $after[2] / $case.iterations
            after_p90_us = $after[18] / $case.iterations
            change_percent = 100 * ($after[10] / $before[10] - 1)
        }
    }
}
$summary | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $EvidenceDirectory 'summary.json')
$summary | Format-Table round, rows, shape, before_median_us, after_median_us, change_percent
