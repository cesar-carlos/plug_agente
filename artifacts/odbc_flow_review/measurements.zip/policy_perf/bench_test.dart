import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:plug_agente/core/config/feature_flags.dart';
import 'package:plug_agente/core/settings/app_settings_store.dart';
import 'package:plug_agente/domain/entities/query_request.dart';
import 'package:plug_agente/domain/query/prepared_query_execution.dart';
import 'package:plug_agente/infrastructure/config/database_type.dart';
import 'package:plug_agente/infrastructure/external_services/native_compatible_acquire_policy.dart' as next;
import 'baseline.dart' as old;

void main() {
  test('paired policy benchmark and decision equivalence', () async {
    dotenv.loadFromString(envString: 'ODBC_USAGE_PROFILE=balanced\nODBC_NATIVE_COMPATIBLE_SQL_ALLOWLIST=');
    final flags = FeatureFlags(InMemoryAppSettingsStore());
    await flags.setEnableOdbcExperimentalDriverAdaptivePooling(true);
    final before = old.NativeCompatibleAcquirePolicy(featureFlags: flags);
    final after = next.NativeCompatibleAcquirePolicy(featureFlags: flags);
    final results = <Object>[];
    for (final sql in [
      'SELECT 1',
      'SELECT TOP 50 id FROM items WHERE id=:id',
      'SELECT count(*) FROM items WHERE id=:id',
      'SELECT id FROM items WHERE id=:id',
      'WITH c AS (SELECT id FROM items) SELECT TOP 500 id FROM c WHERE id=:id',
      'SELECT id FROM items WHERE id=:id /* ${List.filled(200, 'long comment').join(' ')} */',
    ]) {
      for (final params in [false,true]) {
        final request = QueryRequest(id:'bench',agentId:'fixture',query:sql,timestamp:DateTime.utc(2026));
        final prepared = OdbcPreparedQueryExecution(sql:sql, parameters:params ? {'id':42} : null);
        bool original() => before.shouldUseAcquire(databaseType:DatabaseType.sqlServer,request:request,preparedExecution:prepared,timeout:null);
        bool candidate() => after.shouldUseAcquire(databaseType:DatabaseType.sqlServer,request:request,preparedExecution:prepared,timeout:null);
        final expected = original();
        expect(candidate(), expected);
        int measure(bool Function() action) {
          var accepted = 0;
          final watch=Stopwatch()..start();
          for(var i=0;i<1000;i++) { if(action()) accepted++; }
          watch.stop();
          expect(accepted,expected ? 1000 : 0);
          return watch.elapsedMicroseconds;
        }
        final samples=<Object>[];
        for(var r=-5;r<15;r++) {
          late int b,a;
          if(r.isEven) {b=measure(original);a=measure(candidate);} else {a=measure(candidate);b=measure(original);}
          if(r>=0) samples.add({'before_us':b,'after_us':a});
        }
        results.add({'sql':sql,'parameters':params,'accepted':expected,'samples':samples});
      }
    }
    File('build/policy_perf/latest.json').writeAsStringSync(jsonEncode({'runtime':'flutter test JIT','dart':Platform.version,'iterations':1000,'results':results}));
  },timeout:const Timeout(Duration(minutes:5)));
}
