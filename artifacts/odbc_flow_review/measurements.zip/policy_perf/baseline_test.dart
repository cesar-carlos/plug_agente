import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:plug_agente/core/config/feature_flags.dart';
import 'package:plug_agente/core/constants/connection_constants.dart';
import 'package:plug_agente/core/settings/app_settings_store.dart';
import 'package:plug_agente/domain/entities/query_pagination.dart';
import 'package:plug_agente/domain/entities/query_request.dart';
import 'package:plug_agente/domain/entities/sql_command.dart';
import 'package:plug_agente/infrastructure/config/database_type.dart';
import 'baseline.dart';
import 'package:plug_agente/infrastructure/external_services/odbc_gateway_query_preparation.dart';

void main() {
  setUp(() {
    dotenv.clean();
    // Release gate imports .env into process env; dotenv overrides take precedence.
    dotenv.loadFromString(
      envString: 'ODBC_READ_ONLY_BATCH_NATIVE_POOL_ENABLED=false',
    );
  });

  group('NativeCompatibleAcquirePolicy pure classification', () {
    test('normalizeSql strips comments, collapses whitespace and trailing semicolons', () {
      expect(
        NativeCompatibleAcquirePolicy.normalizeSql(
          'SELECT   id /* note */ FROM t;; -- trailing',
        ),
        'select id from t',
      );
    });

    test('isProbeQuery recognizes safe scalar probes', () {
      expect(NativeCompatibleAcquirePolicy.isProbeQuery('SELECT 1'), isTrue);
      expect(NativeCompatibleAcquirePolicy.isProbeQuery('select @@version as v'), isTrue);
      expect(NativeCompatibleAcquirePolicy.isProbeQuery('SELECT id FROM users'), isFalse);
    });

    test('isExplicitlyLimitedSelect accepts small explicit limits and rejects wildcards/large limits', () {
      expect(NativeCompatibleAcquirePolicy.isExplicitlyLimitedSelect('SELECT TOP 10 id FROM users'), isTrue);
      expect(NativeCompatibleAcquirePolicy.isExplicitlyLimitedSelect('SELECT id FROM users LIMIT 50'), isTrue);
      expect(NativeCompatibleAcquirePolicy.isExplicitlyLimitedSelect('SELECT TOP 10 * FROM users'), isFalse);
      expect(NativeCompatibleAcquirePolicy.isExplicitlyLimitedSelect('SELECT id FROM users LIMIT 500'), isFalse);
      expect(NativeCompatibleAcquirePolicy.isExplicitlyLimitedSelect('SELECT id FROM users'), isFalse);
    });

    test('isTransactionalDml accepts INSERT/UPDATE/DELETE/MERGE and rejects OUTPUT/RETURNING and selects', () {
      expect(NativeCompatibleAcquirePolicy.isTransactionalDml('INSERT INTO t (a) VALUES (1)'), isTrue);
      expect(NativeCompatibleAcquirePolicy.isTransactionalDml('UPDATE t SET a = 1'), isTrue);
      expect(NativeCompatibleAcquirePolicy.isTransactionalDml('DELETE FROM t WHERE a = 1 RETURNING a'), isFalse);
      expect(NativeCompatibleAcquirePolicy.isTransactionalDml('INSERT INTO t OUTPUT inserted.id VALUES (1)'), isFalse);
      expect(NativeCompatibleAcquirePolicy.isTransactionalDml('SELECT 1'), isFalse);
    });
  });

  group('NativeCompatibleAcquirePolicy.shouldUseAcquire', () {
    for (final databaseType in DatabaseType.values) {
      test('preserves commented parameterized classifications for ${databaseType.name}', () async {
        dotenv.loadFromString(envString: 'ODBC_USAGE_PROFILE=balanced\nODBC_NATIVE_COMPATIBLE_SQL_ALLOWLIST=');
        final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
        final eligible = databaseType != DatabaseType.sybaseAnywhere;
        final cases = <String, bool>{
          '/* lead */ SELECT 1;; -- end': eligible,
          'SELECT /* projection */ TOP 50 id FROM items WHERE id = :id;': eligible,
          'SELECT count(*) FROM items WHERE id = :id': eligible,
          'SELECT exists (SELECT id FROM items WHERE id = :id)': eligible,
          'WITH c AS (SELECT id FROM items) SELECT TOP 500 id FROM c': eligible,
          'SELECT TOP 1001 id FROM items WHERE id = :id': false,
          'SELECT TOP 50 * FROM items WHERE id = :id': false,
          'SELECT id FROM items WHERE id = :id': false,
        };
        for (final entry in cases.entries) {
          expect(
            policy.shouldUseAcquire(
              databaseType: databaseType,
              request: _request(entry.key),
              preparedExecution: _prepared(entry.key, parameters: const {'id': 1}),
              timeout: null,
            ),
            entry.value,
            reason: entry.key,
          );
        }
      });
    }

    test('rechecks profile changes between calls for the same SQL', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      const sql = 'SELECT id FROM items';
      for (final profile in ['balanced', 'highThroughput', 'balanced']) {
        dotenv.loadFromString(envString: 'ODBC_USAGE_PROFILE=$profile\nODBC_NATIVE_COMPATIBLE_SQL_ALLOWLIST=');
        expect(
          policy.shouldUseAcquire(
            databaseType: DatabaseType.sqlServer,
            request: _request(sql),
            preparedExecution: _prepared(sql),
            timeout: null,
          ),
          profile == 'highThroughput',
        );
      }
    });

    test('returns false when adaptive pooling is disabled', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: false));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT 1'),
          preparedExecution: _prepared('SELECT 1'),
          timeout: null,
        ),
        isFalse,
      );
    });

    test('returns false when expectMultipleResults is set', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT 1', expectMultipleResults: true),
          preparedExecution: _prepared('SELECT 1'),
          timeout: null,
        ),
        isFalse,
      );
    });

    test('returns true for a probe query on SQL Server when enabled', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT 1'),
          preparedExecution: _prepared('SELECT 1'),
          timeout: null,
        ),
        isTrue,
      );
    });

    test('returns false for SQL Anywhere even with a safe shape', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sybaseAnywhere,
          request: _request('SELECT 1'),
          preparedExecution: _prepared('SELECT 1'),
          timeout: null,
        ),
        isFalse,
      );
    });

    test('returns false when a custom timeout is provided', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT 1'),
          preparedExecution: _prepared('SELECT 1'),
          timeout: const Duration(seconds: 5),
          defaultQueryTimeout: const Duration(seconds: 60),
          connectionString: 'Driver={ODBC Driver};Server=localhost;',
        ),
        isFalse,
      );
    });

    test('returns true when timeout matches configured default', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT 1'),
          preparedExecution: _prepared('SELECT 1'),
          timeout: const Duration(seconds: 60),
          defaultQueryTimeout: const Duration(seconds: 60),
          connectionString: 'Driver={ODBC Driver};Server=localhost;',
        ),
        isTrue,
      );
    });

    test('returns true for COUNT aggregate queries', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.postgresql,
          request: _request('SELECT COUNT(*) FROM users'),
          preparedExecution: _prepared('SELECT COUNT(*) FROM users'),
          timeout: null,
        ),
        isTrue,
      );
    });

    test('returns false for unsafe result shapes', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT * FROM users'),
          preparedExecution: _prepared('SELECT * FROM users'),
          timeout: null,
        ),
        isFalse,
      );
    });

    test('returns true when paginated (safe shape) on PostgreSQL', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.postgresql,
          request: _request(
            'SELECT id FROM users',
            pagination: const QueryPaginationRequest(page: 1, pageSize: 10),
          ),
          preparedExecution: _prepared('SELECT id FROM users'),
          timeout: null,
        ),
        isTrue,
      );
    });

    test('returns true for bounded parameterized SELECT on SQL Server', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT id FROM users WHERE id = :id'),
          preparedExecution: _prepared(
            'SELECT TOP 10 id FROM users WHERE id = ?',
            parameters: const {'id': 1},
          ),
          timeout: null,
        ),
        isTrue,
      );
    });

    test('returns true for bounded SELECT without highThroughput profile', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.postgresql,
          request: _request('SELECT id FROM users LIMIT 100'),
          preparedExecution: _prepared('SELECT id FROM users LIMIT 100'),
          timeout: null,
        ),
        isTrue,
      );
    });

    test('honors the env-driven allowlist for exact normalized SQL', () async {
      dotenv.loadFromString(envString: 'ODBC_NATIVE_COMPATIBLE_SQL_ALLOWLIST=select id from users');
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseAcquire(
          databaseType: DatabaseType.sqlServer,
          request: _request('SELECT id FROM users'),
          preparedExecution: _prepared('SELECT id FROM users'),
          timeout: null,
        ),
        isTrue,
      );
    });
  });

  group('NativeCompatibleAcquirePolicy.shouldUseReadOnlyBatchParallel', () {
    test('returns false by default when env gate is off', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'SELECT 1'),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: null,
        ),
        isFalse,
      );
    });

    test('returns true for homogeneous SELECT batch on SQL Server when gate is on', () async {
      dotenv.loadFromString(envString: 'ODBC_READ_ONLY_BATCH_NATIVE_POOL_ENABLED=true');
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'SELECT 1'),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: null,
          connectionString: 'Driver={ODBC Driver};Server=localhost;',
        ),
        isTrue,
      );
    });

    test('returns false for SQL Anywhere and parameterized commands', () async {
      dotenv.loadFromString(envString: 'ODBC_READ_ONLY_BATCH_NATIVE_POOL_ENABLED=true');
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.sybaseAnywhere,
          commands: const [
            SqlCommand(sql: 'SELECT 1'),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: null,
        ),
        isFalse,
      );
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'SELECT 1 WHERE id = @id', params: {'id': 1}),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: null,
        ),
        isFalse,
      );
    });

    test('returns false for non-default timeout until remembered compatible', () async {
      dotenv.loadFromString(envString: 'ODBC_READ_ONLY_BATCH_NATIVE_POOL_ENABLED=true');
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      const connectionString = 'Driver={ODBC Driver};Server=localhost;';
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'SELECT 1'),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: const Duration(seconds: 5),
          connectionString: connectionString,
        ),
        isFalse,
      );
      policy.rememberNativeCompatibleTimeout(
        connectionString: connectionString,
        timeout: const Duration(seconds: 5),
      );
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'SELECT 1'),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: const Duration(seconds: 5),
          connectionString: connectionString,
        ),
        isTrue,
      );
    });

    test('returns true when timeout matches configured default', () async {
      dotenv.loadFromString(envString: 'ODBC_READ_ONLY_BATCH_NATIVE_POOL_ENABLED=true');
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseReadOnlyBatchParallel(
          databaseType: DatabaseType.postgresql,
          commands: const [
            SqlCommand(sql: 'SELECT 1'),
            SqlCommand(sql: 'SELECT 2'),
          ],
          timeout: ConnectionConstants.defaultQueryTimeout,
          connectionString: 'Driver={PostgreSQL};Server=localhost;',
        ),
        isTrue,
      );
    });
  });

  group('NativeCompatibleAcquirePolicy.shouldUseTransactionalBatch', () {
    test('returns true for all-DML batch on SQL Server when enabled', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseTransactionalBatch(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'INSERT INTO t (a) VALUES (1)'),
            SqlCommand(sql: 'UPDATE t SET a = 2'),
          ],
        ),
        isTrue,
      );
    });

    test('returns false when any command is not native-compatible DML', () async {
      final policy = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        policy.shouldUseTransactionalBatch(
          databaseType: DatabaseType.sqlServer,
          commands: const [
            SqlCommand(sql: 'INSERT INTO t (a) VALUES (1)'),
            SqlCommand(sql: 'SELECT 1'),
          ],
        ),
        isFalse,
      );
    });

    test('returns false for empty commands and when disabled', () async {
      final enabled = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: true));
      expect(
        enabled.shouldUseTransactionalBatch(
          databaseType: DatabaseType.sqlServer,
          commands: const [],
        ),
        isFalse,
      );

      final disabled = NativeCompatibleAcquirePolicy(featureFlags: await _flags(enabled: false));
      expect(
        disabled.shouldUseTransactionalBatch(
          databaseType: DatabaseType.sqlServer,
          commands: const [SqlCommand(sql: 'INSERT INTO t (a) VALUES (1)')],
        ),
        isFalse,
      );
    });
  });
}

Future<FeatureFlags> _flags({required bool enabled}) async {
  final flags = FeatureFlags(InMemoryAppSettingsStore());
  await flags.setEnableOdbcExperimentalDriverAdaptivePooling(enabled);
  return flags;
}

QueryRequest _request(
  String sql, {
  QueryPaginationRequest? pagination,
  bool expectMultipleResults = false,
}) {
  return QueryRequest(
    id: 'req-test',
    agentId: 'agent-test',
    query: sql,
    timestamp: DateTime(2024, 2, 3),
    pagination: pagination,
    expectMultipleResults: expectMultipleResults,
  );
}

OdbcPreparedQueryExecution _prepared(String sql, {Map<String, dynamic>? parameters}) {
  return OdbcPreparedQueryExecution(sql: sql, parameters: parameters);
}

