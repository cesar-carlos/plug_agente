import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:odbc_fast/odbc_fast.dart';
import 'package:plug_agente/domain/entities/bulk_insert_request.dart';
import 'baseline.dart' as baseline;
import 'row.dart' as candidate;

Object? sink;
void main(List<String> args) {
  final results = <Object>[];
  for (final type in BulkInsertColumnType.values) {
    for (final nullable in [false, true]) {
      final request = BulkInsertRequest(
        table: 'fixture',
        columns: [BulkInsertColumn(name: 'value', type: type, nullable: nullable,
          maxLen: [BulkInsertColumnType.text, BulkInsertColumnType.decimal, BulkInsertColumnType.binary].contains(type) ? 64 : 0)],
        rows: List.generate(10000, (i) => [
          if (nullable && i % 10 == 0) null else switch (type) {
            BulkInsertColumnType.i32 || BulkInsertColumnType.i64 => i,
            BulkInsertColumnType.text => 'item-$i-abcdefghijklmnopqrstuvwxyz',
            BulkInsertColumnType.decimal => '123.45',
            BulkInsertColumnType.binary => Uint8List.fromList([0,255,1,2,3]),
            BulkInsertColumnType.timestamp => DateTime.utc(2026, 1, 1),
          },
        ]),
      );
      final beforeBuilder = baseline.OdbcNativeBulkInsertBuilder.fromRequest(request);
      final afterBuilder = candidate.OdbcNativeBulkInsertBuilder.fromRequest(request);
      final expected = beforeBuilder.build();
      final actual = afterBuilder.build();
      if (expected.length != actual.length) throw StateError('Length differs');
      for (var i = 0; i < expected.length; i++) {
        if (expected[i] != actual[i]) throw StateError('Bytes differ: $type $i');
      }
      for (final full in [false,true]) {
        int measure(BulkInsertBuilder Function(BulkInsertRequest) prepare, BulkInsertBuilder builder) {
          final watch = Stopwatch()..start();
          for (var i = 0; i < 10; i++) {
            sink = (full ? prepare(request) : builder).build();
          }
          return watch.elapsedMicroseconds;
        }
        final samples = <Object>[];
        for (var round = -5; round < 15; round++) {
          late int before, after;
          if (round.isEven) {
            before = measure(baseline.OdbcNativeBulkInsertBuilder.fromRequest,beforeBuilder);
            after = measure(candidate.OdbcNativeBulkInsertBuilder.fromRequest,afterBuilder);
          } else {
            after = measure(candidate.OdbcNativeBulkInsertBuilder.fromRequest,afterBuilder);
            before = measure(baseline.OdbcNativeBulkInsertBuilder.fromRequest,beforeBuilder);
          }
          if(round >= 0) samples.add({'before_us':before,'after_us':after});
        }
        results.add({'type':type.name,'nullable':nullable,'full':full,'samples':samples});
      }
    }
  }
  stdout.writeln(jsonEncode({'dart':Platform.version,'rows':10000,'iterations':10,'results':results}));
}
