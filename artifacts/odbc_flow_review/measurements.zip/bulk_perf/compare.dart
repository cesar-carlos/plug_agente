import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:odbc_fast/odbc_fast.dart';
import 'package:plug_agente/domain/entities/bulk_insert_request.dart';
import 'baseline.dart' as old;
import 'candidate.dart' as next;

Object? sink;
void main() {
  final results = <Object>[];
  for (final size in [100, 10000, 50000]) {
    for (final nullEvery in [0, 10, 1]) {
      final request = BulkInsertRequest(
        table: 'fixture',
        columns: [
          for (final type in BulkInsertColumnType.values)
            BulkInsertColumn(name: type.name, type: type, nullable: true, maxLen: 64),
        ],
        rows: List.generate(size, (i) => [
          for (final type in BulkInsertColumnType.values)
            if (nullEvery > 0 && i % nullEvery == 0) null
            else switch (type) {
              BulkInsertColumnType.i32 || BulkInsertColumnType.i64 => i,
              BulkInsertColumnType.text => 'item-$i',
              BulkInsertColumnType.decimal => '123.45',
              BulkInsertColumnType.binary => Uint8List.fromList([1,2,3]),
              BulkInsertColumnType.timestamp => DateTime.utc(2026,1,1),
            },
        ]),
      );
      final expected = old.OdbcNativeBulkInsertBuilder.fromRequest(request).build();
      final actual = next.OdbcNativeBulkInsertBuilder.fromRequest(request).build();
      if (expected.length != actual.length) throw StateError('Length mismatch');
      for (var i = 0; i < expected.length; i++) {
        if (expected[i] != actual[i]) throw StateError('Byte mismatch at $i');
      }
      for (final encode in [false, true]) {
        final iterations = size == 100 ? 500 : size == 10000 ? 20 : 5;
        int measure(BulkInsertBuilder Function(BulkInsertRequest) build) {
          final watch = Stopwatch()..start();
          for (var i = 0; i < iterations; i++) {
            final builder = build(request);
            sink = encode ? builder.build() : builder;
          }
          return watch.elapsedMicroseconds;
        }
        final samples = <Object>[];
        for (var round = -6; round < 15; round++) {
          late int before;
          late int after;
          if (round.isEven) {
            before = measure(old.OdbcNativeBulkInsertBuilder.fromRequest);
            after = measure(next.OdbcNativeBulkInsertBuilder.fromRequest);
          } else {
            after = measure(next.OdbcNativeBulkInsertBuilder.fromRequest);
            before = measure(old.OdbcNativeBulkInsertBuilder.fromRequest);
          }
          if (round >= 0) samples.add({'before_us': before, 'after_us': after});
        }
        results.add({'rows': size, 'null_every': nullEvery, 'encode': encode, 'iterations': iterations, 'samples': samples});
      }
    }
  }
  stdout.writeln(jsonEncode({'dart': Platform.version, 'results': results}));
}
